"""Minecraft server manager for T-Panel. Uses Docker + itzg/minecraft-server."""
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import current_user, login_required
import os, re, json, shutil, subprocess, sqlite3, secrets
from pathlib import Path

mc_bp = Blueprint('minecraft', __name__)


def _db():
    from app import DATABASE_PATH
    conn = sqlite3.connect(DATABASE_PATH, timeout=20)
    conn.row_factory = sqlite3.Row
    conn.execute('''CREATE TABLE IF NOT EXISTS minecraft_servers (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
        name TEXT NOT NULL, container_name TEXT NOT NULL UNIQUE,
        port INTEGER NOT NULL UNIQUE, version TEXT NOT NULL, server_type TEXT NOT NULL,
        memory_mb INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    conn.commit()
    return conn


def _docker(args, timeout=30, input_text=None):
    if not shutil.which('docker'):
        raise RuntimeError('Docker is not installed. Run the T-Panel installer with Minecraft Docker support enabled.')
    p = subprocess.run(['docker'] + args, capture_output=True, text=True, timeout=timeout, input=input_text)
    if p.returncode:
        raise RuntimeError((p.stderr or p.stdout or 'Docker command failed').strip()[-1200:])
    return p.stdout.strip()


def _owned(server_id):
    con = _db()
    try:
        row = con.execute('SELECT * FROM minecraft_servers WHERE id=? AND user_id=?', (server_id, int(current_user.get_id()))).fetchone()
        return dict(row) if row else None
    finally:
        con.close()


def _status(container):
    try:
        return _docker(['inspect', '-f', '{{.State.Status}}', container], timeout=10) or 'unknown'
    except Exception:
        return 'removed'


@mc_bp.route('/minecraft')
@login_required
def minecraft_home():
    con = _db()
    try:
        rows = con.execute('SELECT * FROM minecraft_servers WHERE user_id=? ORDER BY id DESC', (int(current_user.get_id()),)).fetchall()
        servers = [dict(r) for r in rows]
    finally:
        con.close()
    for s in servers:
        s['status'] = _status(s['container_name'])
    return render_template('minecraft.html', servers=servers, panel_name='T-Panel')


@mc_bp.route('/minecraft/create', methods=['POST'])
@login_required
def minecraft_create():
    name = (request.form.get('name') or '').strip()
    version = (request.form.get('version') or 'LATEST').strip().upper()
    stype = (request.form.get('server_type') or 'PAPER').strip().upper()
    try:
        port = int(request.form.get('port', '25565'))
        memory = int(request.form.get('memory', '2048'))
    except ValueError:
        flash('Port and memory must be numbers.', 'error'); return redirect(url_for('minecraft.minecraft_home'))
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _-]{0,39}', name):
        flash('Server name: use 1–40 letters, numbers, spaces, _ or -.', 'error'); return redirect(url_for('minecraft.minecraft_home'))
    if not (1024 <= port <= 65535) or not (1024 <= memory <= 32768):
        flash('Port must be 1024–65535 and memory 1024–32768 MB.', 'error'); return redirect(url_for('minecraft.minecraft_home'))
    if stype not in {'PAPER','VANILLA','FABRIC','FORGE','PURPUR'}:
        flash('Unsupported server software.', 'error'); return redirect(url_for('minecraft.minecraft_home'))
    if version != 'LATEST' and not re.fullmatch(r'[0-9]+(?:\.[0-9]+){1,2}', version):
        flash('Invalid Minecraft version.', 'error'); return redirect(url_for('minecraft.minecraft_home'))
    con = _db()
    try:
        if con.execute('SELECT 1 FROM minecraft_servers WHERE port=?', (port,)).fetchone():
            flash('That port is already assigned in T-Panel.', 'error'); return redirect(url_for('minecraft.minecraft_home'))
        sid = secrets.token_hex(5)
        cname = 'tpanel-mc-' + sid
        data_root = Path(os.environ.get('TPANEL_MINECRAFT_DATA', '/opt/T-Panel/minecraft-data'))
        data_dir = data_root / cname
        data_dir.mkdir(parents=True, exist_ok=True)
        # Pulling is performed by Docker on first start; server is isolated in its own container.
        args = ['run','-d','--name',cname,'--restart','unless-stopped','-p',f'{port}:25565/tcp','-p',f'{port}:25565/udp',
                '--memory',f'{memory}m','--cpus','2','-e','EULA=TRUE','-e',f'TYPE={stype}', '-e',f'VERSION={version}',
                '-e','ONLINE_MODE=TRUE','-e','ENABLE_RCON=true','-e','RCON_PASSWORD='+secrets.token_urlsafe(24),
                '-v',f'{data_dir}:/data','itzg/minecraft-server:latest']
        _docker(args, timeout=180)
        cur = con.execute('INSERT INTO minecraft_servers(user_id,name,container_name,port,version,server_type,memory_mb) VALUES(?,?,?,?,?,?,?)',
                          (int(current_user.get_id()), name, cname, port, version, stype, memory))
        con.commit()
        flash(f'Minecraft server “{name}” created. First startup may take a few minutes while the image and server files download.', 'success')
    except Exception as e:
        try:
            if 'cname' in locals(): _docker(['rm','-f',cname], timeout=20)
        except Exception: pass
        flash('Could not create server: ' + str(e), 'error')
    finally:
        con.close()
    return redirect(url_for('minecraft.minecraft_home'))


@mc_bp.route('/minecraft/<int:server_id>/action', methods=['POST'])
@login_required
def minecraft_action(server_id):
    s = _owned(server_id)
    if not s: return jsonify(success=False,error='Server not found'),404
    action = request.form.get('action','')
    allowed = {'start':['start'], 'stop':['stop'], 'restart':['restart']}
    if action not in allowed: return jsonify(success=False,error='Invalid action'),400
    try:
        _docker(allowed[action]+[s['container_name']], timeout=60)
        return jsonify(success=True,status=_status(s['container_name']))
    except Exception as e: return jsonify(success=False,error=str(e)),500


@mc_bp.route('/minecraft/<int:server_id>/console', methods=['GET','POST'])
@login_required
def minecraft_console(server_id):
    s = _owned(server_id)
    if not s: return jsonify(success=False,error='Server not found'),404
    if request.method == 'POST':
        cmd = (request.json or {}).get('command','') if request.is_json else request.form.get('command','')
        cmd = cmd.strip()
        if not cmd or len(cmd)>256 or any(ord(c)<32 for c in cmd): return jsonify(success=False,error='Invalid command'),400
        try:
            # The image's RCON console is used; shell input is never interpolated.
            out = _docker(['exec',s['container_name'],'rcon-cli',cmd],timeout=15)
            return jsonify(success=True,output=out or 'Command sent.')
        except Exception as e: return jsonify(success=False,error=str(e)),500
    try: logs = _docker(['logs','--tail','250',s['container_name']],timeout=15)
    except Exception as e: logs = str(e)
    return jsonify(success=True,logs=logs,status=_status(s['container_name']))


@mc_bp.route('/minecraft/<int:server_id>/delete', methods=['POST'])
@login_required
def minecraft_delete(server_id):
    s = _owned(server_id)
    if not s: flash('Server not found.', 'error'); return redirect(url_for('minecraft.minecraft_home'))
    if request.form.get('confirm') != 'DELETE': flash('Type DELETE to confirm server removal.', 'error'); return redirect(url_for('minecraft.minecraft_home'))
    try:
        _docker(['rm','-f',s['container_name']],timeout=30)
        con = _db()
        try: con.execute('DELETE FROM minecraft_servers WHERE id=? AND user_id=?',(server_id,int(current_user.get_id()))); con.commit()
        finally: con.close()
        data_root = Path(os.environ.get('TPANEL_MINECRAFT_DATA','/opt/T-Panel/minecraft-data')) / s['container_name']
        shutil.rmtree(data_root, ignore_errors=True)
        flash('Minecraft server and its files were deleted.', 'success')
    except Exception as e: flash('Delete failed: '+str(e), 'error')
    return redirect(url_for('minecraft.minecraft_home'))
