#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with sudo: sudo ./install.sh"; exit 1; fi
APP_DIR="/opt/t-panel"
DATA_DIR="/var/lib/t-panel"
SERVICE="t-panel"
echo "=== T PANEL Installer ==="
read -r -p "Panel web port [8088]: " PORT
PORT="${PORT:-8088}"
if ! [[ "$PORT" =~ ^[0-9]+$ ]] || (( PORT < 1024 || PORT > 65535 )); then echo "Invalid port."; exit 1; fi
if command -v ss >/dev/null 2>&1 && ss -ltnH | awk '{print $4}' | grep -Eq "(^|:)${PORT}$"; then
  echo "ERROR: TCP port $PORT is already in use. Choose another port or stop the service using it."
  exit 1
fi
read -r -p "Admin username [admin]: " ADMIN
ADMIN="${ADMIN:-admin}"
read -r -s -p "Admin password (min 10 characters): " PASSWORD; echo
if (( ${#PASSWORD} < 10 )); then echo "Password must be at least 10 characters."; exit 1; fi
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 python3-venv python3-pip docker.io curl ca-certificates openssh-client
id -u tpanel >/dev/null 2>&1 || useradd --system --home-dir "$DATA_DIR" --shell /usr/sbin/nologin tpanel
systemctl enable --now docker
usermod -aG docker tpanel
mkdir -p "$APP_DIR" "$DATA_DIR/server" "$DATA_DIR/backups"
cp -r ./* "$APP_DIR/"
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --upgrade pip
"$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"
export T_PANEL_PORT="$PORT" T_PANEL_ADMIN="$ADMIN" T_PANEL_PASSWORD="$PASSWORD"
"$APP_DIR/venv/bin/python" - <<'PY'
import os, json, secrets, hashlib
p="/var/lib/t-panel/config.json"
salt=secrets.token_hex(16)
pw=hashlib.pbkdf2_hmac("sha256", os.environ["T_PANEL_PASSWORD"].encode(), salt.encode(), 240000).hex()
json.dump({"port":int(os.environ["T_PANEL_PORT"]),"username":os.environ["T_PANEL_ADMIN"],"salt":salt,"password_hash":pw,"secret":secrets.token_hex(32)},open(p,"w"))
os.chmod(p,0o600)
PY
chown -R root:root "$APP_DIR"
chown -R tpanel:tpanel "$DATA_DIR"
cat > /etc/systemd/system/${SERVICE}.service <<EOF
[Unit]
Description=T PANEL Minecraft Server Manager
After=network.target docker.service
Wants=docker.service

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=T_PANEL_CONFIG=$DATA_DIR/config.json
Environment=T_PANEL_DATA=$DATA_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/app.py
Restart=on-failure
RestartSec=3
User=tpanel
Group=tpanel
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full
ReadWritePaths=$DATA_DIR

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now "$SERVICE"
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "$PORT/tcp" || true
fi
sleep 2
if ! systemctl is-active --quiet "$SERVICE"; then
  echo "ERROR: T PANEL service did not start. Recent logs:"
  journalctl -u "$SERVICE" -n 60 --no-pager || true
  exit 1
fi
unset PASSWORD
echo
echo "T PANEL installed."
echo "Panel URL: http://$(hostname -I | awk '{print $1}'):$PORT"
echo "If the page still does not open, allow TCP $PORT in your VPS provider's cloud firewall/security group."
echo "Service: systemctl status t-panel"
echo "Logs: journalctl -u t-panel -f"
echo "Server files: $DATA_DIR/server"
