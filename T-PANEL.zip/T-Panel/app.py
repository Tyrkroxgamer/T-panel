#!/usr/bin/env python3
import os, json, time, threading, subprocess, secrets, hashlib, hmac, urllib.request, urllib.parse, zipfile, io, pathlib, shlex, datetime, re
from functools import wraps
from flask import Flask, request, session, redirect, url_for, render_template, jsonify, flash, send_file, abort

APP_DIR = pathlib.Path(__file__).resolve().parent
DATA = pathlib.Path(os.environ.get("T_PANEL_DATA", "/var/lib/t-panel"))
CONFIG_PATH = pathlib.Path(os.environ.get("T_PANEL_CONFIG", str(DATA / "config.json")))
SERVER = DATA / "server"
BACKUPS = DATA / "backups"
for p in (SERVER, BACKUPS): p.mkdir(parents=True, exist_ok=True)
config = json.loads(CONFIG_PATH.read_text())
USERS_PATH = DATA / "users.json"
if not USERS_PATH.exists():
    _salt=config["salt"]
    USERS_PATH.write_text(json.dumps({config["username"]:{"salt":_salt,"password_hash":config["password_hash"],"role":"admin"}}))
    os.chmod(USERS_PATH,0o600)
def load_users(): return read_json(USERS_PATH,{}) if "read_json" in globals() else json.loads(USERS_PATH.read_text())
def save_users(users): USERS_PATH.write_text(json.dumps(users,indent=2)); os.chmod(USERS_PATH,0o600)
def verify_user(username,password):
    user=load_users().get(username)
    if not user: return False
    digest=hashlib.pbkdf2_hmac("sha256",password.encode(),user["salt"].encode(),240000).hex()
    return hmac.compare_digest(digest,user["password_hash"])
app = Flask(__name__)
app.secret_key = config["secret"]
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024
proc = None  # Minecraft runs in Docker.
proc_lock = threading.RLock()
CONTAINER = "t-panel-minecraft"
SETTINGS_PATH = DATA / "settings.json"
NODES_PATH = DATA / "remote-nodes.json"
def read_json(path, default):
    try: return json.loads(path.read_text())
    except Exception: return default
def write_json(path, value):
    path.write_text(json.dumps(value, indent=2)); os.chmod(path, 0o600)
def fetch_json(url, timeout=15):
    req=urllib.request.Request(url, headers={"User-Agent":"TPanel/2.0 (Minecraft server management)"})
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read(8*1024*1024))
DEFAULT_SETTINGS = {"software":"PAPER", "version":"1.21.8", "ram":"2G", "port":25565, "motd":"T PANEL Minecraft Server", "max_players":20, "eula_accepted":False}
settings = read_json(SETTINGS_PATH, DEFAULT_SETTINGS.copy())
for k,v in DEFAULT_SETTINGS.items(): settings.setdefault(k,v)
write_json(SETTINGS_PATH, settings)
RCON_PASSWORD = config.get("secret", "change-this-secret")[:24]
console_lines = []
MAX_LINES = 1200
SOFTWARES = ["VANILLA", "PAPER", "PURPUR", "FOLIA", "FABRIC", "FORGE", "NEOFORGE", "QUILT", "SPIGOT", "BUKKIT", "VELOCITY", "WATERFALL", "BUNGEECORD"]
PROXY_SOFTWARES = {"VELOCITY", "WATERFALL", "BUNGEECORD"}
MOD_SOFTWARES = {"FABRIC", "FORGE", "NEOFORGE", "QUILT"}
PLUGIN_SOFTWARES = {"PAPER", "PURPUR", "FOLIA", "SPIGOT", "BUKKIT", "PAPER"}

def add_line(s):
    global console_lines
    console_lines.append({"time": time.strftime("%H:%M:%S"), "text": str(s)[:4000]})
    console_lines = console_lines[-MAX_LINES:]

def reader(p):
    try:
        for line in iter(p.stdout.readline, ""):
            if not line: break
            add_line(line.rstrip())
    except Exception as e: add_line("Console reader: " + str(e))

def docker(*args, timeout=30, check=True):
    return subprocess.run(["docker", *args], capture_output=True, text=True, timeout=timeout, check=check)

def container_exists():
    r = docker("inspect", "-f", "{{.State.Status}}", CONTAINER, check=False)
    return r.returncode == 0

def server_status():
    r = docker("inspect", "-f", "{{.State.Running}}", CONTAINER, check=False)
    return "ONLINE" if r.returncode == 0 and r.stdout.strip() == "true" else "OFFLINE"

def server_stats():
    if server_status() != "ONLINE": return {"cpu":"—","memory":"—","memory_percent":"—"}
    try:
        r=docker("stats","--no-stream","--format","{{.CPUPerc}}|{{.MemUsage}}|{{.MemPerc}}",CONTAINER,timeout=8,check=False)
        parts=r.stdout.strip().split("|",2)
        if r.returncode==0 and len(parts)==3: return {"cpu":parts[0],"memory":parts[1],"memory_percent":parts[2]}
    except Exception: pass
    return {"cpu":"Unavailable","memory":"Unavailable","memory_percent":"—"}

def docker_log_reader():
    p = subprocess.Popen(["docker", "logs", "-f", "--since", "1s", CONTAINER],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    try:
        for line in iter(p.stdout.readline, ""):
            if not line: break
            add_line(line.rstrip())
    except Exception as e:
        add_line("Docker log reader: " + str(e))
    finally:
        try: p.wait(timeout=2)
        except Exception: p.kill()

def safe_path(rel):
    rel = (rel or "").replace("\\", "/").lstrip("/")
    target = (SERVER / rel).resolve()
    if target != SERVER.resolve() and SERVER.resolve() not in target.parents:
        abort(400, "Invalid path")
    return target

def login_required(fn):
    @wraps(fn)
    def wrapped(*a, **kw):
        if not session.get("logged_in"): return redirect(url_for("login"))
        return fn(*a, **kw)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    def wrapped(*a, **kw):
        if not session.get("logged_in"): return redirect(url_for("login"))
        if session.get("role") != "admin": abort(403)
        return fn(*a, **kw)
    return wrapped

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username","")
        password = request.form.get("password","")
        if verify_user(username, password):
            session.clear(); session["logged_in"] = True; session["role"] = load_users()[username].get("role","user"); session["username"] = username
            return redirect(url_for("dashboard"))
        time.sleep(.7); flash("Login failed. Check username and password.", "error")
    return render_template("login.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method=="POST":
        username=request.form.get("username","").strip(); password=request.form.get("password",""); confirm=request.form.get("confirm","")
        users=load_users()
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,24}",username): flash("Username must be 3–24 letters, numbers, dots, dashes or underscores.","error")
        elif username in users: flash("Username already exists.","error")
        elif len(password)<10: flash("Password must be at least 10 characters.","error")
        elif password!=confirm: flash("Passwords do not match.","error")
        else:
            salt=secrets.token_hex(16); digest=hashlib.pbkdf2_hmac("sha256",password.encode(),salt.encode(),240000).hex()
            users[username]={"salt":salt,"password_hash":digest,"role":"user"}; save_users(users)
            flash("Account created. Sign in to continue."); return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/users", methods=["GET","POST"])
@login_required
def users_page():
    if session.get("role")!="admin": abort(403)
    users=load_users()
    if request.method=="POST":
        username=request.form.get("username","").strip(); password=request.form.get("password","")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,24}",username) or len(password)<10: flash("Enter a valid username and password of at least 10 characters.","error")
        elif username in users: flash("Username already exists.","error")
        else:
            salt=secrets.token_hex(16); digest=hashlib.pbkdf2_hmac("sha256",password.encode(),salt.encode(),240000).hex(); users[username]={"salt":salt,"password_hash":digest,"role":"user"}; save_users(users); flash("User created.")
        return redirect(url_for("users_page"))
    return render_template("users.html",users=users)

@app.route("/logout", methods=["POST"])
def logout():
    session.clear(); return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    try: files = sorted(SERVER.iterdir(), key=lambda p:p.name.lower())
    except OSError: files=[]
    return render_template("dashboard.html", status=server_status(), files=files,
                           server_exists=(SERVER/"server.jar").exists(), lines=console_lines[-100:], settings=settings, stats=server_stats())

@app.route("/api/status")
@login_required
def api_status():
    return jsonify(status=server_status(), pid=proc.pid if proc and proc.poll() is None else None)

@app.route("/api/console")
@login_required
def api_console():
    return jsonify(lines=console_lines[-300:])

@app.route("/api/command", methods=["POST"])
@admin_required
def api_command():
    cmd = request.json.get("command","") if request.is_json else request.form.get("command","")
    cmd = cmd.strip()
    if not cmd or len(cmd) > 500 or any(ord(c) < 32 for c in cmd):
        return jsonify(error="Invalid command"), 400
    if server_status() != "ONLINE": return jsonify(error="Server is offline"), 409
    if settings.get("software") in PROXY_SOFTWARES: return jsonify(error="Minecraft RCON commands are unavailable on proxy software."), 409
    try:
        r = docker("exec", CONTAINER, "rcon-cli", cmd, timeout=12, check=False)
        output = (r.stdout + r.stderr).strip()
        if output: add_line(output)
        if r.returncode != 0: return jsonify(error=output or "RCON command failed"), 500
    except Exception as e:
        return jsonify(error=str(e)), 500
    return jsonify(ok=True)

@app.route("/server/<action>", methods=["POST"])
@admin_required
def server_action(action):
    if action == "start":
        if not settings.get("eula_accepted", False):
            flash("Review and accept the Minecraft EULA in Server setup before starting.", "error")
            return redirect(url_for("dashboard"))
        if action == "start" and server_status() == "ONLINE":
            flash("Server is already running."); return redirect(url_for("dashboard"))
        ram = request.form.get("ram", settings.get("ram", "2G"))
        if ram not in ("1G","2G","3G","4G","6G","8G","12G","16G","24G","32G"): ram=settings.get("ram","2G")
        settings["ram"] = ram; write_json(SETTINGS_PATH, settings)
        version = settings.get("version", "1.21.8")
        software = settings.get("software", "PAPER")
        port = int(settings.get("port", 25565))
        try:
            if container_exists(): docker("rm", "-f", CONTAINER, check=False)
            add_line("T PANEL: starting Minecraft with Docker (itzg/minecraft-server).")
            internal_port = 25577 if software in PROXY_SOFTWARES else 25565
            docker_args=["run", "-d", "--name", CONTAINER, "--restart", "no",
                   "-p", f"{port}:{internal_port}", "-e", "EULA=TRUE", "-e", "TYPE="+software,
                   "-e", "VERSION="+version, "-e", "MEMORY="+ram, "-e", "SERVER_PORT="+str(internal_port), "-e", "MAX_PLAYERS="+str(settings.get("max_players",20)), "-e", "MOTD="+str(settings.get("motd","T PANEL Minecraft Server")),
                   "-v", str(SERVER)+":/data", "itzg/minecraft-server:latest"]
            if software not in PROXY_SOFTWARES:
                docker_args += ["-e", "ENABLE_RCON=true", "-e", "RCON_PASSWORD="+RCON_PASSWORD]
            docker(*docker_args, timeout=120)
            threading.Thread(target=docker_log_reader, daemon=True).start()
            flash("Docker Minecraft server is starting. First launch may take a few minutes while the image downloads.")
        except Exception as e:
            add_line("Docker start failed: "+str(e))
            flash("Docker start failed: "+str(e), "error")
    elif action == "stop":
        try:
            if server_status() == "ONLINE":
                docker("stop", "-t", "30", CONTAINER, timeout=45)
                flash("Docker Minecraft server stopped.")
            else: flash("Server is already offline.")
        except Exception as e: flash("Docker stop failed: "+str(e), "error")
    elif action == "restart":
        try:
            if server_status() == "ONLINE":
                docker("restart", "-t", "30", CONTAINER, timeout=45)
                threading.Thread(target=docker_log_reader, daemon=True).start()
                flash("Docker Minecraft server restarted.")
            else: flash("Server is offline; use Start Server.")
        except Exception as e: flash("Docker restart failed: "+str(e), "error")
    else: abort(404)
    return redirect(url_for("dashboard"))

@app.route("/server/configure", methods=["POST"])
@admin_required
def configure_server():
    software=request.form.get("software","PAPER").upper()
    version=request.form.get("version",settings.get("version","1.21.8")).strip()
    if request.form.get("accept_eula")!="yes":
        flash("You must accept the Minecraft EULA before preparing a server.","error"); return redirect(url_for("dashboard"))
    if software not in SOFTWARES or not re.fullmatch(r"[A-Za-z0-9_.-]{1,32}",version):
        flash("Choose a supported software and valid version.","error"); return redirect(url_for("dashboard"))
    if server_status()=="ONLINE":
        flash("Stop the server before changing software or version.","error"); return redirect(url_for("dashboard"))
    settings.update({"software":software,"version":version,"eula_accepted":True}); write_json(SETTINGS_PATH,settings)
    add_line(f"Configured {software} {version}; Docker will fetch the selected software at next start.")
    flash(f"{software} {version} selected. Start the server to download and prepare it.")
    return redirect(url_for("dashboard"))

@app.route("/install-paper", methods=["POST"])
@admin_required
def install_paper():
    # Compatibility endpoint retained for the dashboard's setup form.
    if request.form.get("accept_eula") != "yes":
        flash("You must accept the Minecraft EULA before preparing a server.", "error")
        return redirect(url_for("dashboard"))
    version=request.form.get("version", settings.get("version", "1.21.8")).strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,32}", version):
        flash("Invalid version identifier.", "error"); return redirect(url_for("dashboard"))
    if server_status()=="ONLINE":
        flash("Stop the server before changing software or version.", "error"); return redirect(url_for("dashboard"))
    settings["software"]="PAPER"; settings["version"]=version; settings["eula_accepted"]=True; write_json(SETTINGS_PATH,settings)
    add_line(f"Configured PAPER {version}; Docker will fetch the selected server software at next start.")
    flash(f"Paper {version} selected. Start the server to download and prepare it.")
    return redirect(url_for("dashboard"))

@app.route("/api/versions")
@login_required
def api_versions():
    software=request.args.get("software",settings.get("software","PAPER")).upper()
    if software not in SOFTWARES: return jsonify(error="Unsupported software"),400
    try:
        if software == "VANILLA":
            data=fetch_json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")
            versions=[{"id":v["id"],"type":v.get("type","release")} for v in data.get("versions",[]) if v.get("type")=="release"]
        elif software in {"PAPER","FOLIA","WATERFALL"}:
            project={"PAPER":"paper","FOLIA":"folia","WATERFALL":"waterfall"}[software]
            data=fetch_json(f"https://api.papermc.io/v2/projects/{project}")
            versions=[{"id":v,"type":"release"} for v in data.get("versions",[])]
        elif software == "PURPUR":
            data=fetch_json("https://api.purpurmc.org/v2/purpur")
            versions=[{"id":v,"type":"release"} for v in data.get("versions",[])]
        elif software in {"FABRIC","QUILT","FORGE","NEOFORGE"}:
            loader={"FABRIC":"fabric","QUILT":"quilt","FORGE":"forge","NEOFORGE":"neoforge"}[software]
            data=fetch_json("https://api.modrinth.com/v2/tag/game_version")
            versions=[{"id":v["version"],"type":"release"} for v in data if v.get("version_type")=="release"]
        elif software == "BUNGEECORD":
            versions=[{"id":"latest","type":"release"}]
        else:
            data=fetch_json("https://api.papermc.io/v2/projects/paper")
            versions=[{"id":v,"type":"release"} for v in data.get("versions",[])]
        return jsonify(software=software,versions=versions[:500])
    except Exception as e:
        return jsonify(error="Could not load official version list: "+str(e), versions=[]),502

@app.route("/files")
@login_required
def files():
    rel=request.args.get("path","")
    folder=safe_path(rel)
    if not folder.exists() or not folder.is_dir(): abort(404)
    entries=[]
    for p in sorted(folder.iterdir(), key=lambda p:(not p.is_dir(),p.name.lower())):
        entries.append({"name":p.name,"dir":p.is_dir(),"size":p.stat().st_size if p.is_file() else 0})
    return render_template("files.html", path=rel, entries=entries, parent=str(pathlib.PurePosixPath(rel).parent) if rel else "")

@app.route("/files/upload", methods=["POST"])
@admin_required
def upload_file():
    rel=request.form.get("path","")
    folder=safe_path(rel)
    if not folder.is_dir(): abort(400,"Target folder does not exist")
    upload=request.files.get("file")
    if not upload or not upload.filename: flash("Choose a file to upload.","error")
    else:
        name=pathlib.Path(upload.filename).name
        if name in (".","..") or len(name)>180: abort(400)
        dest=(folder/name).resolve()
        if dest.parent != folder.resolve(): abort(400)
        upload.save(dest); flash("Uploaded "+name)
    return redirect(url_for("files",path=rel))

@app.route("/files/create-folder", methods=["POST"])
@admin_required
def create_folder():
    rel=request.form.get("path",""); folder=safe_path(rel)
    name=request.form.get("name","").strip()
    if not re.fullmatch(r"[A-Za-z0-9 _.-]{1,80}",name): flash("Invalid folder name.","error")
    else:
        try: (folder/name).mkdir(); flash("Folder created.")
        except Exception as e: flash("Could not create folder: "+str(e),"error")
    return redirect(url_for("files",path=rel))

@app.route("/files/delete", methods=["POST"])
@admin_required
def delete_file():
    rel=request.form.get("path",""); target=safe_path(rel)
    if target == SERVER.resolve(): abort(400)
    if server_status()=="ONLINE" and (target.name.endswith(".jar") or target.name in {"server.properties","eula.txt"}):
        flash("Stop the server before deleting active server files.","error")
    else:
        try:
            if target.is_dir():
                import shutil; shutil.rmtree(target)
            else: target.unlink()
            flash("Deleted "+target.name)
        except Exception as e: flash("Delete failed: "+str(e),"error")
    return redirect(url_for("files",path=request.form.get("parent","")))

@app.route("/files/download")
@login_required
def download_file():
    target=safe_path(request.args.get("path",""))
    if not target.is_file(): abort(404)
    return send_file(target,as_attachment=True,download_name=target.name)

@app.route("/files/extract", methods=["POST"])
@admin_required
def extract_zip():
    rel=request.form.get("path",""); archive=safe_path(rel)
    if server_status()=="ONLINE": flash("Stop the server before extracting an archive.","error"); return redirect(url_for("files",path=request.form.get("parent","")))
    if not archive.is_file() or archive.suffix.lower()!=".zip": flash("Choose a ZIP file.","error")
    else:
        try:
            base=archive.parent.resolve()
            with zipfile.ZipFile(archive) as z:
                for item in z.infolist():
                    dest=(base/item.filename).resolve()
                    if dest != base and base not in dest.parents: raise ValueError("Archive contains an unsafe path")
                    if item.file_size > 256*1024*1024: raise ValueError("An archive entry is too large")
                z.extractall(base)
            flash("Archive extracted: "+archive.name)
        except Exception as e: flash("Extract failed: "+str(e),"error")
    return redirect(url_for("files",path=request.form.get("parent","")))

@app.route("/file")
@login_required
def read_file():
    rel=request.args.get("path","")
    p=safe_path(rel)
    if not p.is_file() or p.stat().st_size > 1024*1024: abort(400, "File missing or larger than 1 MiB")
    try: content=p.read_text(errors="replace")
    except OSError as e: abort(400,str(e))
    return render_template("edit.html", path=rel, content=content)

@app.route("/file/save", methods=["POST"])
@admin_required
def save_file():
    rel=request.form.get("path","")
    p=safe_path(rel)
    if p.exists() and (not p.is_file() or p.stat().st_size > 1024*1024): abort(400)
    content=request.form.get("content","")
    if len(content)>1024*1024: abort(413)
    p.parent.mkdir(parents=True,exist_ok=True); p.write_text(content)
    flash("File saved."); return redirect(url_for("read_file",path=rel))

@app.route("/backup", methods=["POST"])
@admin_required
def backup():
    stamp=time.strftime("%Y%m%d-%H%M%S")
    dest=BACKUPS/f"backup-{stamp}.zip"
    try:
        with zipfile.ZipFile(dest,"w",zipfile.ZIP_DEFLATED) as z:
            for p in SERVER.rglob("*"):
                if p.is_file(): z.write(p,p.relative_to(SERVER))
        flash(f"Backup created: {dest.name}")
    except Exception as e: flash("Backup failed: "+str(e),"error")
    return redirect(url_for("dashboard"))

@app.route("/backups")
@login_required
def backups():
    return render_template("backups.html", backups=sorted(BACKUPS.glob("*.zip"),reverse=True))

@app.route("/download-backup/<name>")
@login_required
def download_backup(name):
    if "/" in name or "\\" in name or not name.endswith(".zip"): abort(400)
    p=BACKUPS/name
    if not p.is_file(): abort(404)
    return send_file(p,as_attachment=True)


@app.route("/plugins", methods=["GET", "POST"])
@login_required
def plugins_page():
    query=request.args.get("q","").strip(); results=[]; installed=[]
    software=settings.get("software","PAPER")
    plugins=SERVER/"plugins"; plugins.mkdir(exist_ok=True)
    installed=sorted(x.name for x in plugins.glob("*.jar"))
    if query:
        try:
            facets=json.dumps([["project_type:plugin"]])
            url="https://api.modrinth.com/v2/search?"+urllib.parse.urlencode({"query":query,"facets":facets,"limit":"12"})
            data=fetch_json(url,12)
            results=[{"id":x["project_id"],"slug":x["slug"],"title":x["title"],"description":x.get("description","")[:180],"downloads":x.get("downloads",0)} for x in data.get("hits",[])]
        except Exception as e: flash("Plugin search failed: "+str(e),"error")
    return render_template("plugins.html",query=query,results=results,installed=installed,software=software)

@app.route("/plugins/install", methods=["POST"])
@admin_required
def plugin_install():
    project=request.form.get("project","").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]{2,80}",project): abort(400)
    if server_status()=="ONLINE": flash("Stop the server before installing plugins.","error"); return redirect(url_for("plugins_page"))
    try:
        if settings.get("software") not in PLUGIN_SOFTWARES: raise ValueError("Plugin JARs require Paper/Purpur/Folia/Spigot/Bukkit. Select a compatible software first.")
        versions=fetch_json("https://api.modrinth.com/v2/project/"+project+"/version",15)
        loader=settings.get("software","PAPER").lower()
        if loader in ("purpur", "folia"): loader="paper"
        compatible=[v for v in versions if settings.get("version") in v.get("game_versions",[]) and loader in v.get("loaders",[])]
        chosen=compatible or [v for v in versions if loader in v.get("loaders",[])]
        if not chosen: raise ValueError("No compatible published version found for the selected Minecraft version/software")
        if not chosen: raise ValueError("No published versions found")
        files=chosen[0].get("files",[]); file=next((f for f in files if f.get("primary")),files[0] if files else None)
        if not file: raise ValueError("Plugin download not found")
        name=pathlib.Path(file["filename"]).name
        if not name.endswith(".jar") or "/" in name or "\\" in name: raise ValueError("Invalid plugin filename")
        req=urllib.request.Request(file["url"],headers={"User-Agent":"TPanel/2.0"})
        blob=urllib.request.urlopen(req,timeout=30).read(80*1024*1024+1)
        if len(blob)>80*1024*1024: raise ValueError("Plugin file is too large")
        dest=SERVER/"plugins"/name; dest.parent.mkdir(exist_ok=True); dest.write_bytes(blob)
        flash("Plugin installed: "+name+". Restart the server to load it.")
    except Exception as e: flash("Plugin install failed: "+str(e),"error")
    return redirect(url_for("plugins_page"))

@app.route("/plugins/delete", methods=["POST"])
@admin_required
def plugin_delete():
    name=request.form.get("name","")
    if pathlib.Path(name).name!=name or not name.endswith(".jar"): abort(400)
    if server_status()=="ONLINE": flash("Stop the server before removing plugins.","error")
    else:
        try: (SERVER/"plugins"/name).unlink(); flash("Plugin removed: "+name)
        except OSError as e: flash("Could not remove plugin: "+str(e),"error")
    return redirect(url_for("plugins_page"))

@app.route("/mods", methods=["GET"])
@login_required
def mods_page():
    query=request.args.get("q","").strip(); results=[]; installed=[]
    mods_dir=SERVER/"mods"; mods_dir.mkdir(exist_ok=True)
    installed=sorted(x.name for x in mods_dir.glob("*.jar"))
    if query:
        try:
            facets=json.dumps([["project_type:mod"]])
            data=fetch_json("https://api.modrinth.com/v2/search?"+urllib.parse.urlencode({"query":query,"facets":facets,"limit":"12"}),12)
            results=[{"id":x["project_id"],"slug":x["slug"],"title":x["title"],"description":x.get("description","")[:180],"downloads":x.get("downloads",0)} for x in data.get("hits",[])]
        except Exception as e: flash("Mod search failed: "+str(e),"error")
    return render_template("mods.html",query=query,results=results,installed=installed,software=settings.get("software","PAPER"))

@app.route("/mods/install", methods=["POST"])
@admin_required
def mod_install():
    project=request.form.get("project","").strip()
    if not re.fullmatch(r"[A-Za-z0-9_-]{2,80}",project): abort(400)
    software=settings.get("software","")
    if software not in MOD_SOFTWARES: flash("Select Fabric, Forge, NeoForge or Quilt in Admin Settings before installing mods.","error"); return redirect(url_for("mods_page"))
    if server_status()=="ONLINE": flash("Stop the server before installing mods.","error"); return redirect(url_for("mods_page"))
    try:
        versions=fetch_json("https://api.modrinth.com/v2/project/"+project+"/version",15)
        loader=software.lower()
        compatible=[v for v in versions if settings.get("version") in v.get("game_versions",[]) and loader in v.get("loaders",[])]
        if not compatible: raise ValueError("No compatible version for this loader and Minecraft version")
        files=compatible[0].get("files",[]); item=next((f for f in files if f.get("primary")),files[0] if files else None)
        if not item or not item.get("filename","").endswith(".jar"): raise ValueError("Mod JAR not found")
        blob=urllib.request.urlopen(urllib.request.Request(item["url"],headers={"User-Agent":"TPanel/2.0"}),timeout=30).read(80*1024*1024+1)
        if len(blob)>80*1024*1024: raise ValueError("Mod is too large")
        (SERVER/"mods").mkdir(exist_ok=True); (SERVER/"mods"/pathlib.Path(item["filename"]).name).write_bytes(blob)
        flash("Mod installed. Restart server to load it.")
    except Exception as e: flash("Mod install failed: "+str(e),"error")
    return redirect(url_for("mods_page"))

@app.route("/mods/delete", methods=["POST"])
@admin_required
def mod_delete():
    name=request.form.get("name","")
    if pathlib.Path(name).name!=name or not name.endswith(".jar"): abort(400)
    if server_status()=="ONLINE": flash("Stop the server before removing mods.","error")
    else:
        try: (SERVER/"mods"/name).unlink(); flash("Mod removed: "+name)
        except OSError as e: flash("Could not remove mod: "+str(e),"error")
    return redirect(url_for("mods_page"))

@app.route("/players", methods=["GET","POST"])
@login_required
def players_page():
    result="Server is offline. Start it to manage players."
    if server_status()=="ONLINE" and settings.get("software") in PROXY_SOFTWARES:
        result="Player moderation via RCON is not available on proxy software. Connect a backend server or use the proxy's own management tools."
    elif server_status()=="ONLINE":
        try: result=docker("exec",CONTAINER,"rcon-cli","list",timeout=8,check=False).stdout.strip() or "No player list returned."
        except Exception as e: result=str(e)
    if request.method=="POST":
        if session.get("role")!="admin": abort(403)
        if settings.get("software") in PROXY_SOFTWARES:
            flash("Player actions via RCON are unavailable on proxy software.","error"); return redirect(url_for("players_page"))
        action=request.form.get("action",""); player=request.form.get("player","").strip()
        if not re.fullmatch(r"[A-Za-z0-9_]{3,16}",player): flash("Enter a valid Minecraft username.","error")
        elif server_status()!="ONLINE": flash("Start the server first.","error")
        elif action not in ("kick","ban","pardon","op","deop"): abort(400)
        else:
            try:
                r=docker("exec",CONTAINER,"rcon-cli",action,player,timeout=10,check=False)
                flash((r.stdout+r.stderr).strip() or f"Command sent: {action} {player}","error" if r.returncode else "")
            except Exception as e: flash(str(e),"error")
        return redirect(url_for("players_page"))
    return render_template("players.html",player_list=result)

@app.route("/settings", methods=["GET","POST"])
@login_required
def settings_page():
    global settings
    if session.get("role")!="admin": abort(403)
    if request.method=="POST":
        software=request.form.get("software","PAPER").upper(); version=request.form.get("version","1.21.8").strip(); ram=request.form.get("ram","2G")
        try: port=int(request.form.get("port","25565")); max_players=int(request.form.get("max_players","20"))
        except ValueError: flash("Port and max players must be numbers.","error"); return redirect(url_for("settings_page"))
        motd=request.form.get("motd","T PANEL Minecraft Server").strip()[:120]
        if software not in SOFTWARES: flash("Invalid server software.","error")
        elif not re.fullmatch(r"[A-Za-z0-9_.-]{1,32}",version): flash("Invalid version identifier.","error")
        elif ram not in ("1G","2G","3G","4G","6G","8G","12G","16G","24G","32G"): flash("Invalid RAM selection.","error")
        elif not 1024<=port<=65535 or not 1<=max_players<=1000: flash("Port must be 1024–65535 and max players 1–1000.","error")
        elif server_status()=="ONLINE": flash("Stop the server before changing server settings.","error")
        else:
            settings.update({"software":software,"version":version,"ram":ram,"port":port,"motd":motd,"max_players":max_players})
            write_json(SETTINGS_PATH,settings); flash("Settings saved. Start the server to apply them.")
        return redirect(url_for("settings_page"))
    return render_template("settings.html",settings=settings)

@app.route("/nodes", methods=["GET","POST"])
@login_required
def nodes_page():
    if session.get("role")!="admin": abort(403)
    nodes=read_json(NODES_PATH,[])
    if request.method=="POST":
        action=request.form.get("action","add")
        name=request.form.get("name","").strip(); host=request.form.get("host","").strip(); user=request.form.get("user","").strip()
        if action=="delete":
            nodes=[n for n in nodes if n.get("id")!=request.form.get("id")]; write_json(NODES_PATH,nodes); flash("Node removed.")
        elif not name or not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}",host) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,31}",user): flash("Enter valid node name, hostname/IP and SSH user.","error")
        elif not request.form.get("port","22").isdigit() or not 1 <= int(request.form.get("port","22")) <= 65535: flash("SSH port must be 1–65535.","error")
        else:
            nodes.append({"id":secrets.token_hex(5),"name":name[:64],"host":host,"user":user,"port":int(request.form.get("port",22))})
            write_json(NODES_PATH,nodes); flash("Node saved. Configure SSH key access for the panel service user before connecting.")
        return redirect(url_for("nodes_page"))
    return render_template("nodes.html",nodes=nodes)

@app.route("/nodes/test/<node_id>", methods=["POST"])
@login_required
def node_test(node_id):
    if session.get("role")!="admin": abort(403)
    node=next((n for n in read_json(NODES_PATH,[]) if n.get("id")==node_id),None)
    if not node: abort(404)
    try:
        r=subprocess.run(["ssh","-o","BatchMode=yes","-o","ConnectTimeout=5","-p",str(node["port"]),f"{node['user']}@{node['host']}","printf T_PANEL_NODE_OK"],capture_output=True,text=True,timeout=8)
        flash("SSH node connection successful." if r.returncode==0 and "T_PANEL_NODE_OK" in r.stdout else "SSH test failed: "+(r.stderr.strip() or "configure a key for the tpanel service user"),"error" if r.returncode else "")
    except Exception as e: flash("SSH test failed: "+str(e),"error")
    return redirect(url_for("nodes_page"))

@app.route("/nodes/containers/<node_id>", methods=["GET"])
@login_required
def node_containers(node_id):
    if session.get("role")!="admin": abort(403)
    node=next((n for n in read_json(NODES_PATH,[]) if n.get("id")==node_id),None)
    if not node: abort(404)
    try:
        remote_cmd="docker ps -a --format '{{.Names}}|{{.Status}}|{{.Image}}'"
        r=subprocess.run(["ssh","-o","BatchMode=yes","-o","ConnectTimeout=5","-p",str(node["port"]),f"{node['user']}@{node['host']}",remote_cmd],capture_output=True,text=True,timeout=12)
        if r.returncode: raise RuntimeError(r.stderr.strip() or "SSH command failed")
        containers=[]
        for line in r.stdout.splitlines():
            parts=line.split("|",2)
            if len(parts)==3 and re.fullmatch(r"[A-Za-z0-9_.-]{1,128}",parts[0]): containers.append({"name":parts[0],"status":parts[1],"image":parts[2]})
        return render_template("node_containers.html",node=node,containers=containers)
    except Exception as e:
        flash("Could not list remote containers: "+str(e),"error"); return redirect(url_for("nodes_page"))

@app.route("/nodes/container-action/<node_id>", methods=["POST"])
@login_required
def node_container_action(node_id):
    if session.get("role")!="admin": abort(403)
    node=next((n for n in read_json(NODES_PATH,[]) if n.get("id")==node_id),None)
    if not node: abort(404)
    action=request.form.get("action",""); name=request.form.get("name","")
    if action not in ("start","stop","restart") or not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}",name): abort(400)
    try:
        remote_cmd="docker "+action+" "+shlex.quote(name)
        r=subprocess.run(["ssh","-o","BatchMode=yes","-o","ConnectTimeout=5","-p",str(node["port"]),f"{node['user']}@{node['host']}",remote_cmd],capture_output=True,text=True,timeout=30)
        flash(("Remote container "+action+" successful: "+name) if r.returncode==0 else "Remote action failed: "+(r.stderr.strip() or r.stdout.strip()),"error" if r.returncode else "")
    except Exception as e: flash("Remote action failed: "+str(e),"error")
    return redirect(url_for("node_containers",node_id=node_id))

@app.route("/health")
def health(): return "ok",200

if __name__ == "__main__":
    from werkzeug.serving import run_simple
    run_simple("0.0.0.0", int(config["port"]), app, use_reloader=False, threaded=True)
