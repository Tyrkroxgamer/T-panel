/* avm-extras.js - boot intro, header clock, title decode (works with avm-hud.js; fully optional) */
(function () {
  'use strict';
  var doc = document, root = doc.documentElement;
  var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  function $(s, c) { return (c || doc).querySelector(s); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function ready(fn) { if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', fn); else fn(); }

  ready(function () {
    if (!$('.sidebar') || !$('.header')) return;            /* standalone pages: skip */
    var lite = root.classList.contains('hud-lite');

    /* clock chip (placed before the HUD buttons) */
    var hr = $('.header-right');
    if (hr && !$('.ex-chip')) {
      var ck = doc.createElement('span'); ck.className = 'ex-chip'; ck.innerHTML = '<span class="dot"></span><span class="t">--:--:--</span>';
      hr.insertBefore(ck, hr.firstChild);
      var t = $('.t', ck), p = function (n) { return (n < 10 ? '0' : '') + n; };
      (function tick() { var d = new Date(); t.textContent = p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()); ck.classList.toggle('off', !navigator.onLine); setTimeout(tick, 1000); })();
    }

    /* boot intro once per session (not in Lite / reduced motion) */
    var booted = false; try { booted = sessionStorage.getItem('exBooted') === '1'; } catch (e) {}
    var shown = false;
    if (!booted && !reduce && !lite) {
      try { sessionStorage.setItem('exBooted', '1'); } catch (e) {}
      var logo = $('.sidebar-header .logo img'), nm = $('.sidebar-header .logo span');
      var b = doc.createElement('div'); b.id = 'exBoot'; b.setAttribute('aria-hidden', 'true');
      b.innerHTML = '<div class="scan"></div><div class="ex-boot-core"><div class="ex-boot-ring">' + (logo ? '<img src="' + esc(logo.getAttribute('src')) + '" alt="">' : '') + '</div>' +
        '<div class="ex-boot-name">' + esc(nm ? nm.textContent.trim() : 'T PANEL') + '</div><div class="ex-boot-sub">INITIALIZING SYSTEM</div><div class="ex-boot-bar"><i></i></div></div>';
      doc.body.appendChild(b); shown = true;
      setTimeout(function () { if (b.parentNode) b.parentNode.removeChild(b); }, 2100);   /* safety net */
    }

    /* header title decode effect */
    var ht = $('.header-title');
    if (ht && !reduce && !lite && ht.children.length === 0) {
      var fin = ht.textContent, chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#%&$@', n = 0, total = 14;
      if (fin && fin.trim().length > 1 && fin.length < 40) {
        ht.setAttribute('aria-label', fin.trim());
        setTimeout(function () {
          var iv = setInterval(function () {
            n++; var out = '';
            for (var i = 0; i < fin.length; i++) { var c = fin[i]; out += (c === ' ' || i < (n / total) * fin.length) ? c : chars[Math.floor(Math.random() * chars.length)]; }
            ht.textContent = out; if (n >= total) { clearInterval(iv); ht.textContent = fin; }
          }, 45);
          setTimeout(function () { clearInterval(iv); ht.textContent = fin; }, 900);
        }, shown ? 1350 : 0);
      }
    }
  });
})();
