/* avm-features.js - helpers (window.vf) + VPS list extras: bulk select, tags/groups, Insights/Apps links. */
(function () {
  'use strict';
  var doc = document;
  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return [].slice.call((c || doc).querySelectorAll(s)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  var toastEl, toastT;
  function toast(msg, err) {
    if (!toastEl) { toastEl = doc.createElement('div'); toastEl.className = 'vf-toast'; doc.body.appendChild(toastEl); }
    toastEl.textContent = msg; toastEl.className = 'vf-toast show' + (err ? ' err' : '');
    clearTimeout(toastT); toastT = setTimeout(function () { toastEl.classList.remove('show'); }, err ? 4500 : 2400);
  }
  function api(url, method, data) {
    var o = { method: method || 'GET', headers: { 'Accept': 'application/json' }, credentials: 'same-origin' };
    if (data !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(data); }
    else if (o.method !== 'GET') { o.headers['Content-Type'] = 'application/json'; o.body = '{}'; }
    return fetch(url, o).then(function (r) {
      return r.json().catch(function () { return { success: false, error: 'Server error (' + r.status + ')' }; }).then(function (j) {
        if (!j.success) throw new Error(j.error || ('Request failed (' + r.status + ')'));
        return j;
      });
    });
  }
  /* run an api call with a button spinner + toast on error */
  function act(btn, fn, okMsg) {
    if (btn) btn.disabled = true;
    return Promise.resolve().then(fn).then(function (r) { if (okMsg) toast(okMsg); return r; })
      .catch(function (e) { toast(e.message, true); throw e; })
      .then(function (r) { if (btn) btn.disabled = false; return r; }, function (e) { if (btn) btn.disabled = false; });
  }
  function modal(id, open) { var m = doc.getElementById(id); if (m) m.classList.toggle('open', open !== false); }
  function ago(iso) {
    if (!iso) return 'never';
    var d = new Date(iso); if (isNaN(d)) return iso;
    var s = (Date.now() - d.getTime()) / 1000;
    if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago'; return Math.floor(s / 86400) + ' d ago';
  }
  function dur(sec) { sec = Math.round(sec); if (sec < 60) return sec + 's'; if (sec < 3600) return Math.round(sec / 60) + ' min'; if (sec < 86400) return (sec / 3600).toFixed(1) + ' h'; return (sec / 86400).toFixed(1) + ' d'; }
  window.vf = { api: api, act: act, toast: toast, esc: esc, modal: modal, ago: ago, dur: dur, $: $, $$: $$ };

  doc.addEventListener('click', function (e) {          /* generic: tabs, [data-close] modals, copy */
    var t = e.target.closest('.vf-tab');
    if (t && t.dataset.pane) {
      $$('.vf-tab', t.parentNode).forEach(function (x) { x.classList.toggle('on', x === t); });
      $$('.vf-pane').forEach(function (p) { p.classList.toggle('on', p.id === t.dataset.pane); });
      try { history.replaceState(null, '', '#' + t.dataset.pane); } catch (x) {}
    }
    var c = e.target.closest('[data-close]'); if (c) modal(c.dataset.close, false);
    var cp = e.target.closest('[data-copy]');
    if (cp) { var txt = cp.dataset.copy || (cp.previousElementSibling || {}).textContent || ''; (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject()).then(function () { toast('Copied'); }, function () { toast('Copy failed', true); }); }
    if (e.target.classList && e.target.classList.contains('vf-modal')) e.target.classList.remove('open');
  });
  doc.addEventListener('DOMContentLoaded', function () {
    var h = (location.hash || '').slice(1), t = h && $('.vf-tab[data-pane="' + h + '"]'); if (t) t.click();
  });

  /* ------------------------------------------------------------------ VPS list extras */
  function initList() {
    var cards = $$('.vps-card[data-id]'); if (!cards.length) return;
    var meta = {}, sel = {}, filter = null;
    var grid = $('#vpsGrid') || cards[0].parentNode;

    var bar = doc.createElement('div'); bar.id = 'vfBulk';
    bar.innerHTML = '<span class="n"><span id="vfN">0</span> selected</span>' +
      '<button class="vf-btn sm" data-a="start"><i class="fas fa-play"></i> Start</button>' +
      '<button class="vf-btn sm" data-a="restart"><i class="fas fa-rotate"></i> Restart</button>' +
      '<button class="vf-btn sm danger" data-a="stop"><i class="fas fa-stop"></i> Stop</button>' +
      '<button class="vf-btn sm" data-a="tag"><i class="fas fa-tags"></i> Tags / group</button>' +
      '<button class="vf-btn sm" data-a="clear">Clear</button>';
    doc.body.appendChild(bar);

    var fb = doc.createElement('div'); fb.id = 'vfFilters'; grid.parentNode.insertBefore(fb, grid);

    function selIds() { return Object.keys(sel).filter(function (k) { return sel[k]; }).map(Number); }
    function refreshBar() { var n = selIds().length; $('#vfN').textContent = n; bar.classList.toggle('on', n > 0); }

    cards.forEach(function (c) {
      var id = c.dataset.id;
      var cb = doc.createElement('input'); cb.type = 'checkbox'; cb.className = 'vf-pick'; cb.title = 'Select for bulk actions';
      cb.addEventListener('change', function () { sel[id] = cb.checked; refreshBar(); });
      cb.addEventListener('click', function (e) { e.stopPropagation(); });
      c.appendChild(cb);
      var ex = doc.createElement('div'); ex.className = 'vf-card-extra'; ex.dataset.for = id;
      var ab = $('.action-buttons', c); if (ab) c.insertBefore(ex, ab); else c.appendChild(ex);
    });

    function renderCard(c) {
      var id = c.dataset.id, m = meta[id] || { tags: [], group: '' }, ex = $('.vf-card-extra', c); if (!ex) return;
      var h = '';
      if (m.group) h += '<span class="vf-chip warn" title="Group"><i class="fas fa-layer-group"></i> ' + esc(m.group) + '</span>';
      m.tags.forEach(function (t) { h += '<span class="vf-chip">#' + esc(t) + '</span>'; });
      h += '<button class="vf-tagbtn" data-edit="' + id + '" type="button">+ tag</button>' +
           '<a class="vf-btn sm" href="/vps/' + id + '/insights"><i class="fas fa-chart-line"></i> Insights</a>' +
           '<a class="vf-btn sm" href="/features/apps?vps=' + id + '"><i class="fas fa-cubes"></i> Apps</a>';
      ex.innerHTML = h;
    }
    function applyFilter() {
      cards.forEach(function (c) {
        var m = meta[c.dataset.id] || { tags: [], group: '' }, show = true;
        if (filter) show = filter.type === 'group' ? m.group === filter.v : m.tags.indexOf(filter.v) >= 0;
        c.style.setProperty('display', show ? '' : 'none', show ? '' : 'important');
      });
    }
    function renderFilters() {
      var groups = {}, tags = {};
      cards.forEach(function (c) { var m = meta[c.dataset.id]; if (!m) return; if (m.group) groups[m.group] = 1; m.tags.forEach(function (t) { tags[t] = 1; }); });
      var h = '<span class="vf-chip' + (filter ? '' : ' on') + '" data-f="">All</span>';
      Object.keys(groups).sort().forEach(function (g) { h += '<span class="vf-chip warn' + (filter && filter.type === 'group' && filter.v === g ? ' on' : '') + '" data-f="group:' + esc(g) + '"><i class="fas fa-layer-group"></i> ' + esc(g) + '</span>'; });
      Object.keys(tags).sort().forEach(function (t) { h += '<span class="vf-chip' + (filter && filter.type === 'tag' && filter.v === t ? ' on' : '') + '" data-f="tag:' + esc(t) + '">#' + esc(t) + '</span>'; });
      h += '<span class="vf-chip mute" data-f="__all">Select all shown</span>';
      fb.innerHTML = h; fb.style.display = (Object.keys(groups).length + Object.keys(tags).length) ? '' : 'none';
      if (!fb.style.display) fb.innerHTML += '';
    }
    fb.addEventListener('click', function (e) {
      var ch = e.target.closest('[data-f]'); if (!ch) return; var f = ch.dataset.f;
      if (f === '__all') { cards.forEach(function (c) { if (c.style.display !== 'none') { var cb = $('.vf-pick', c); cb.checked = true; sel[c.dataset.id] = true; } }); refreshBar(); return; }
      filter = f ? { type: f.split(':')[0], v: f.slice(f.indexOf(':') + 1) } : null; renderFilters(); applyFilter();
    });
    function loadMeta() {
      api('/features/api/meta?ids=' + cards.map(function (c) { return c.dataset.id; }).join(',')).then(function (r) {
        meta = r.meta || {}; cards.forEach(renderCard); renderFilters(); applyFilter();
      }).catch(function () { cards.forEach(renderCard); });
    }

    /* tag / group modal */
    var tm = doc.createElement('div'); tm.className = 'vf-modal'; tm.id = 'vfTagModal';
    tm.innerHTML = '<div class="vf-card"><h3><i class="fas fa-tags"></i> Tags and group</h3>' +
      '<p class="sub" id="vfTagFor"></p>' +
      '<div class="vf-row"><div><label class="l">Tags (comma separated, max 8)</label><input class="vf-input" id="vfTags" placeholder="web, production"></div></div>' +
      '<div class="vf-row"><div><label class="l">Group (one per VPS)</label><input class="vf-input" id="vfGroup" placeholder="e.g. Client A"></div></div>' +
      '<div class="vf-note" id="vfTagMode"></div><div class="vf-inline" style="margin-top:.8rem"><button class="vf-btn primary" id="vfTagSave">Save</button><button class="vf-btn" data-close="vfTagModal">Cancel</button></div></div>';
    doc.body.appendChild(tm);
    var target = null;
    function openTagModal(ids) {
      target = ids; var one = ids.length === 1, m = meta[ids[0]] || { tags: [], group: '' };
      $('#vfTagFor').textContent = one ? 'Editing 1 VPS' : 'Applying to ' + ids.length + ' VPS';
      $('#vfTags').value = one ? m.tags.join(', ') : ''; $('#vfGroup').value = one ? m.group : '';
      $('#vfTagMode').textContent = one ? 'Saved values replace the current ones.' : 'Tags are ADDED to each VPS. Leave the group empty to keep each VPS group as it is.';
      modal('vfTagModal', true); setTimeout(function () { $('#vfTags').focus(); }, 30);
    }
    $('#vfTagSave').addEventListener('click', function () {
      var tags = $('#vfTags').value.split(',').map(function (s) { return s.trim(); }).filter(Boolean), one = target.length === 1;
      var p = { vps_ids: target };
      if (one) { p.set_tags = tags; p.group = $('#vfGroup').value.trim(); } else { p.add_tags = tags; if ($('#vfGroup').value.trim()) p.group = $('#vfGroup').value.trim(); }
      act(this, function () { return api('/features/api/meta', 'POST', p); }, 'Saved').then(function (r) {
        if (r) { for (var k in r.meta) meta[k] = r.meta[k]; cards.forEach(renderCard); renderFilters(); applyFilter(); modal('vfTagModal', false); }
      });
    });
    grid.addEventListener('click', function (e) { var b = e.target.closest('[data-edit]'); if (b) { e.preventDefault(); openTagModal([+b.dataset.edit]); } });

    /* bulk actions */
    bar.addEventListener('click', function (e) {
      var b = e.target.closest('[data-a]'); if (!b) return; var a = b.dataset.a, ids = selIds();
      if (a === 'clear') { cards.forEach(function (c) { $('.vf-pick', c).checked = false; }); sel = {}; refreshBar(); return; }
      if (a === 'tag') { openTagModal(ids); return; }
      if (a !== 'start' && !confirm(a.charAt(0).toUpperCase() + a.slice(1) + ' ' + ids.length + ' VPS?')) return;
      toast('Sending ' + a + ' to ' + ids.length + ' VPS...');
      api('/features/api/bulk', 'POST', { vps_ids: ids, action: a }).then(function (r) { poll(r.job, a); }).catch(function (er) { toast(er.message, true); });
    });
    function poll(job, a) {
      api('/features/api/bulk/' + job).then(function (r) {
        var ok = r.items.filter(function (i) { return i.state === 'ok'; }).length, bad = r.items.filter(function (i) { return i.state === 'failed'; });
        if (!r.done) { toast(a + ': ' + ok + '/' + r.items.length + ' done...'); setTimeout(function () { poll(job, a); }, 1800); return; }
        if (bad.length) toast(ok + ' ok, ' + bad.length + ' failed: ' + bad.map(function (i) { return i.name + ' (' + i.msg + ')'; }).join('; '), true);
        else toast('All ' + ok + ' VPS: ' + a + ' done');
        setTimeout(function () { location.reload(); }, bad.length ? 4500 : 1400);
      }).catch(function (er) { toast(er.message, true); });
    }

    /* touch: swipe a card right = Start, left = Stop (asks first). Vertical scrolling is never blocked. */
    if ('ontouchstart' in window) {
      cards.forEach(function (c) {
        var x0 = 0, y0 = 0, dx = 0, on = false, locked = false;
        var hl = doc.createElement('div'); hl.className = 'vf-swipe-hint l'; hl.textContent = 'Start';
        var hr = doc.createElement('div'); hr.className = 'vf-swipe-hint r'; hr.textContent = 'Stop';
        c.appendChild(hl); c.appendChild(hr);
        c.addEventListener('touchstart', function (e) {
          if (e.touches.length !== 1 || e.target.closest('button, a, input, select, textarea')) { on = false; return; }
          x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; dx = 0; on = true; locked = false;
        }, { passive: true });
        c.addEventListener('touchmove', function (e) {
          if (!on) return; var t = e.touches[0], mx = t.clientX - x0, my = t.clientY - y0;
          if (!locked) { if (Math.abs(my) > 14 && Math.abs(my) > Math.abs(mx)) { on = false; return; } if (Math.abs(mx) > 14 && Math.abs(mx) > Math.abs(my) * 1.6) locked = true; else return; }
          dx = Math.max(-140, Math.min(140, mx)); c.style.transform = 'translateX(' + dx + 'px)'; c.style.transition = 'none';
          hl.style.opacity = dx > 40 ? Math.min(1, dx / 110) : 0; hr.style.opacity = dx < -40 ? Math.min(1, -dx / 110) : 0;
        }, { passive: true });
        function end() {
          if (!on) return; on = false; c.style.transition = 'transform .18s'; c.style.transform = ''; hl.style.opacity = hr.style.opacity = 0;
          if (!locked || Math.abs(dx) < 100) return;
          var a = dx > 0 ? 'start' : 'stop', name = (($('.vps-name, h3, .vps-title', c) || {}).textContent || 'this VPS').trim();
          if (a === 'stop' && !confirm('Stop ' + name + '?')) return;
          toast((a === 'start' ? 'Starting ' : 'Stopping ') + name + '...');
          api('/features/api/bulk', 'POST', { vps_ids: [+c.dataset.id], action: a }).then(function (r) { poll(r.job, a); }).catch(function (er) { toast(er.message, true); });
        }
        c.addEventListener('touchend', end); c.addEventListener('touchcancel', end);
      });
    }
    loadMeta();
  }

  /* VPS detail page: quick links to Insights / Apps */
  function initDetail() {
    var m = location.pathname.match(/^\/vps\/(\d+)\/?$/); if (!m) return;
    var content = $('.content'); if (!content || $('#vfDetailLinks')) return;
    var d = doc.createElement('div'); d.id = 'vfDetailLinks'; d.className = 'vf-inline'; d.style.margin = '0 0 1rem';
    d.innerHTML = '<a class="vf-btn" href="/vps/' + m[1] + '/insights"><i class="fas fa-chart-line"></i> Usage &amp; uptime</a>' +
                  '<a class="vf-btn" href="/features/apps?vps=' + m[1] + '"><i class="fas fa-cubes"></i> One-click apps</a>' +
                  '<a class="vf-btn" href="/automation"><i class="fas fa-bell"></i> Alerts &amp; schedules</a>' +
                  '<a class="vf-btn" href="/tools"><i class="fas fa-terminal"></i> Command runner</a>';
    content.insertBefore(d, content.firstChild);
  }
  function boot() { initList(); initDetail(); }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* ---------------------------------------------------------------- Display settings (themes, effects, text size) + announcements */
(function () {
  'use strict';
  var doc = document, root = doc.documentElement;
  function $(s, c) { return (c || doc).querySelector(s); }
  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function put(k, v) { try { if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} }
  function themes() { return (window.zxTheme ? window.zxTheme.presets : []).map(function (t) { return [t.id, t.name, t.z1, t.z2]; }); }
  function setTheme(id) { if (window.zxTheme) { if (id) window.zxTheme.set(id); else window.zxTheme.reset(); } }
  function setFs(f) { root.classList.remove('vf-fs-s', 'vf-fs-l'); if (f === 's' || f === 'l') root.classList.add('vf-fs-' + f); put('vfFs', f === 'm' ? null : f); }
  function setCalm(on) { root.classList.toggle('vf-calm', on); put('vfCalm', on ? '1' : null); }
  window.vfDisplay = { themes: themes, setTheme: setTheme, setFs: setFs, setCalm: setCalm, open: openPanel };

  var modal;
  function build() {
    modal = doc.createElement('div'); modal.className = 'vf-modal'; modal.id = 'vfDisplayModal';
    modal.innerHTML = '<div class="vf-card hot" style="max-width:520px"><h3><i class="fas fa-sliders"></i> Display settings</h3>' +
      '<label class="l">HUD theme</label><div class="vf-themes" id="vfThemes"></div>' +
      '<div style="margin-top:1rem">' +
      '<div class="vf-opt"><span>Text size</span><span class="vf-seg" id="vfFs"><button data-f="s">Small</button><button data-f="m">Normal</button><button data-f="l">Large</button></span></div>' +
      '<div class="vf-opt"><span>Lite mode <small class="vf-note">(fewer effects, faster on phones)</small></span><label class="vf-switch"><input type="checkbox" id="vfLite"><b></b></label></div>' +
      '<div class="vf-opt"><span>Icon-only sidebar</span><label class="vf-switch"><input type="checkbox" id="vfMini"><b></b></label></div>' +
      '<div class="vf-opt"><span>Calm mode <small class="vf-note">(no animations)</small></span><label class="vf-switch"><input type="checkbox" id="vfCalm"><b></b></label></div>' +
      '<div class="vf-opt"><span>Boot intro animation</span><label class="vf-switch"><input type="checkbox" id="vfBoot"><b></b></label></div></div>' +
      '<div class="vf-inline" style="margin-top:1rem"><button class="vf-btn" id="vfReset">Reset</button><button class="vf-btn primary" data-close="vfDisplayModal">Done</button></div></div>';
    doc.body.appendChild(modal);
    var tg = $('#vfThemes', modal);
    themes().forEach(function (t) {
      var d = doc.createElement('div'); d.className = 'vf-theme'; d.dataset.t = t[0]; d.innerHTML = '<i style="--a:' + t[2] + ';--b:' + t[3] + '"></i>' + t[1]; tg.appendChild(d);
    });
    tg.addEventListener('click', function (e) { var d = e.target.closest('.vf-theme'); if (d) { setTheme(d.dataset.t); sync(); } });
    $('#vfFs', modal).addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) { setFs(b.dataset.f); sync(); } });
    $('#vfLite', modal).addEventListener('change', function () { var b = $('#hudLiteBtn'); if (b && root.classList.contains('hud-lite') !== this.checked) b.click(); });
    $('#vfMini', modal).addEventListener('change', function () { var b = $('#hudMiniBtn'); if (b && root.classList.contains('hud-mini') !== this.checked) b.click(); });
    $('#vfCalm', modal).addEventListener('change', function () { setCalm(this.checked); });
    $('#vfBoot', modal).addEventListener('change', function () { put('vfNoBoot', this.checked ? null : '1'); });
    $('#vfReset', modal).addEventListener('click', function () { setTheme(''); setFs('m'); setCalm(false); put('vfNoBoot', null); sync(); });
  }
  function sync() {
    var cur = window.zxTheme ? window.zxTheme.current() : '';
    [].forEach.call(modal.querySelectorAll('.vf-theme'), function (d) { d.classList.toggle('on', d.dataset.t === cur); });
    var fs = root.classList.contains('vf-fs-s') ? 's' : root.classList.contains('vf-fs-l') ? 'l' : 'm';
    [].forEach.call(modal.querySelectorAll('#vfFs button'), function (b) { b.classList.toggle('on', b.dataset.f === fs); });
    $('#vfLite', modal).checked = root.classList.contains('hud-lite'); $('#vfMini', modal).checked = root.classList.contains('hud-mini');
    $('#vfCalm', modal).checked = root.classList.contains('vf-calm'); $('#vfBoot', modal).checked = get('vfNoBoot') !== '1';
  }
  function openPanel() { if (!modal) build(); sync(); modal.classList.add('open'); }
  doc.addEventListener('click', function (e) { if (e.target.closest('#vfDisplayBtn')) openPanel(); });

  /* announcements: admin posts, everyone sees a bar until they dismiss it */
  function ann() {
    var box = $('#vfAnn'); if (!box || !window.vf) return;
    vf.api('/features/api/announcements').then(function (r) {
      var hid = []; try { hid = JSON.parse(get('vfAnnHidden') || '[]'); } catch (e) {}
      box.innerHTML = r.items.filter(function (a) { return hid.indexOf(a.id) < 0; }).map(function (a) {
        return '<div class="vf-ann ' + vf.esc(a.level) + '" data-id="' + a.id + '"><i class="fas fa-bullhorn"></i><span>' + vf.esc(a.text) + '</span><button aria-label="Dismiss">&times;</button></div>';
      }).join('');
    }).catch(function () {});
    box.addEventListener('click', function (e) {
      var b = e.target.closest('button'), row = b && b.closest('.vf-ann'); if (!row) return;
      var hid = []; try { hid = JSON.parse(get('vfAnnHidden') || '[]'); } catch (x) {}
      hid.push(+row.dataset.id); put('vfAnnHidden', JSON.stringify(hid.slice(-50))); row.remove();
    });
  }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', ann); else ann();
})();
