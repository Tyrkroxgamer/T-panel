#!/usr/bin/env bash
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo bash uninstall.sh"; exit 1; }
APP_DIR="/opt/T-Panel"
SERVICE="T-Panel"
echo "This removes the T-Panel application, service, database, settings, uploads and backups at:"
echo "  $APP_DIR"
echo "It does NOT remove Docker, Minecraft servers, Wings, or other system packages."
read -rp "Type DELETE to permanently remove T-Panel data: " CONFIRM
[[ "$CONFIRM" == "DELETE" ]] || { echo "Cancelled."; exit 0; }
systemctl disable --now "$SERVICE" 2>/dev/null || true
rm -f "/etc/systemd/system/${SERVICE}.service" "/etc/systemd/system/${SERVICE}.service.d/override.conf"
systemctl daemon-reload
rm -rf -- "$APP_DIR"
echo "T-Panel application files and data removed."
