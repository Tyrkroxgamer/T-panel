#!/usr/bin/env bash
set -Eeuo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Run with sudo: sudo ./uninstall.sh"
  exit 1
fi

echo "=== T PANEL Uninstaller ==="
echo "This removes the T PANEL web application and its systemd service."
echo "Minecraft Docker container and server data are kept by default."
read -r -p "Remove T PANEL application and service? [y/N]: " CONFIRM
case "${CONFIRM,,}" in y|yes) ;; *) echo "Cancelled."; exit 0 ;; esac

systemctl disable --now t-panel 2>/dev/null || true
rm -f /etc/systemd/system/t-panel.service
systemctl daemon-reload
rm -rf /opt/t-panel

echo
echo "T PANEL application removed."
echo "Kept: /var/lib/t-panel (server files, backups, login configuration)."
echo "Kept: Docker installation, images, and container 't-panel-minecraft' if present."
echo
read -r -p "Also delete T PANEL data (server files, backups, accounts)? Type DELETE to confirm: " DELETE_DATA
if [[ "$DELETE_DATA" == "DELETE" ]]; then
  # Container mounts this directory, so remove the container first to avoid it continuing to run.
  docker rm -f t-panel-minecraft 2>/dev/null || true
  rm -rf /var/lib/t-panel
  echo "T PANEL data and its Minecraft container removed."
else
  echo "Data retained. You can remove /var/lib/t-panel manually later if desired."
fi

echo
echo "Docker itself was not uninstalled because other apps may use it."
echo "To remove Docker separately, inspect your other containers first."
