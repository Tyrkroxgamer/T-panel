T PANEL — FINAL TEST PACKAGE
============================

What this package changes
- Rebrands the visible top navigation to a large “T” mark + configured panel name.
- Adds a dark navy / cyan / indigo visual theme.
- Installer uses fixed panel branding “T Panel” and asks for the administrator account plus panel URL.
- Default web port is TCP 8088 (not 80). The installer creates Nginx config for that port and opens UFW if UFW is active.
- APP_NAME is configurable in the generated .env file.

Install (Ubuntu/Debian, fresh VPS recommended)
1. Upload and extract this ZIP on the VPS.
2. Enter the extracted T-PANEL folder.
3. Run: sudo bash install.sh
4. Open http://YOUR_SERVER_IP:8088
5. If using a cloud firewall/security group, allow inbound TCP 8088 there too.

Optional settings:
  PANEL_PORT=8088 bash install.sh
  PANEL_URL=http://YOUR_SERVER_IP:8088 bash install.sh

MariaDB startup has retry and direct-daemon fallback logic for minimal containers. This does not bypass OS/container restrictions; a normal Ubuntu/Debian VPS is recommended.

Important feature notes
- This is a rebranded Pterodactyl-based panel, not a new game server daemon.
- Existing server console, files, startup settings, schedules, backups, allocations, and server controls are provided by the underlying panel.
- Minecraft version changes depend on the selected Egg/startup variables and available server jar/image. There is not a newly implemented standalone one-click version changer in this package.
- A dedicated live Minecraft player manager and one-click plugin browser are not implemented here. For now, use the server console and File Manager / SFTP with a compatible Minecraft Egg.
- Remote node/server actions require a separately installed and correctly configured Wings node. The panel alone cannot provide a working node.
- Run on a fresh supported Ubuntu/Debian VPS where possible. No installer can guarantee zero errors on every VPS; package mirrors, DNS, provider firewall, and existing conflicting services can affect installation.
