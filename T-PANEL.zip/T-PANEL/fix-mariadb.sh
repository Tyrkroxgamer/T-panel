#!/usr/bin/env bash
# T Panel MariaDB repair helper for Ubuntu/Debian (run as root).
set -u
if [ "$(id -u)" -ne 0 ]; then echo 'Run: sudo bash fix-mariadb.sh' >&2; exit 1; fi
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y mariadb-server mariadb-client
mkdir -p /run/mysqld /var/log/mysql
chown mysql:mysql /run/mysqld /var/log/mysql 2>/dev/null || true
if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null | tr -d ' ')" = systemd ]; then
  systemctl enable mariadb || true
  systemctl restart mariadb || systemctl start mariadb || true
elif command -v service >/dev/null 2>&1; then
  service mariadb restart || service mariadb start || true
fi
if ! mysqladmin ping --silent >/dev/null 2>&1; then
  if command -v mariadb-install-db >/dev/null 2>&1 && [ ! -d /var/lib/mysql/mysql ]; then
    mariadb-install-db --user=mysql --datadir=/var/lib/mysql || true
  fi
  if command -v mariadbd-safe >/dev/null 2>&1; then
    nohup mariadbd-safe --user=mysql --datadir=/var/lib/mysql --socket=/run/mysqld/mysqld.sock --pid-file=/run/mysqld/mysqld.pid >/var/log/t-panel-mariadb-start.log 2>&1 </dev/null &
  elif command -v mysqld_safe >/dev/null 2>&1; then
    nohup mysqld_safe --user=mysql --datadir=/var/lib/mysql --socket=/run/mysqld/mysqld.sock --pid-file=/run/mysqld/mysqld.pid >/var/log/t-panel-mariadb-start.log 2>&1 </dev/null &
  fi
fi
for i in $(seq 1 30); do
  if mysqladmin ping --silent >/dev/null 2>&1; then echo 'MariaDB is responding.'; exit 0; fi
  sleep 2
done
echo 'MariaDB still did not start. Diagnostics:'
(systemctl status mariadb --no-pager -l 2>&1 || true)
(service mariadb status 2>&1 || true)
(tail -n 80 /var/log/t-panel-mariadb-start.log 2>/dev/null || true)
(journalctl -u mariadb -n 80 --no-pager 2>&1 || true)
exit 1
