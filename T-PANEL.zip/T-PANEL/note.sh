#!/bin/bash
exec bash "$(dirname "${BASH_SOURCE[0]}")/node.sh" "$@"
