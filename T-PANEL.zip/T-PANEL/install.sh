#!/bin/bash
# =====================================================================
#  T Panel (Pterodactyl) - Automatic Installer
#  Usage:  sudo bash install.sh
#  Supports: Ubuntu 20.04/22.04/24.04, Debian 11/12
# =====================================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info() { echo -e "${CYAN}[*]${NC} $1"; }
ok()   { echo -e "${GREEN}[+]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
fail() { echo -e "${RED}[x]${NC} $1"; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Root se chalao:  sudo bash install.sh"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/var/www/pterodactyl"
PANEL_PORT="${PANEL_PORT:-8088}"

. /etc/os-release
case "$ID" in
  ubuntu|debian) ;;
  *) fail "Sirf Ubuntu / Debian supported hai (mila: $ID)" ;;
esac

# ---------------------------------------------------------------------
#  1. Setup: fixed panel branding; ask only for admin account and URL
# ---------------------------------------------------------------------
PANEL_NAME="T Panel"
echo
echo -e "${CYAN}========== T Panel Setup ==========${NC}"
while [ -z "$ADMIN_USERNAME" ]; do read -rp "Username   : " ADMIN_USERNAME; done
while ! [[ "$ADMIN_EMAIL" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]]; do read -rp "Email      : " ADMIN_EMAIL; done
while [ -z "$ADMIN_FIRST" ]; do read -rp "First name : " ADMIN_FIRST; done
while [ -z "$ADMIN_LAST" ];  do read -rp "Last name  : " ADMIN_LAST; done
while true; do
  read -rsp "Password   (min 8 chars): " ADMIN_PASS; echo
  [ "${#ADMIN_PASS}" -ge 8 ] || { warn "Password kam se kam 8 characters ka rakho."; continue; }
  read -rsp "Password again          : " ADMIN_PASS2; echo
  [ "$ADMIN_PASS" = "$ADMIN_PASS2" ] && break
  warn "Password match nahi hua, dobara try karo."
done

# Panel URL: user can enter a domain/IP URL; blank auto-detects the public IP.
echo
read -rp "Panel URL (e.g. http://1.2.3.4:${PANEL_PORT} or https://panel.example.com) [blank = auto-detect]: " INPUT_PANEL_URL
PANEL_URL="${INPUT_PANEL_URL:-${PANEL_URL:-}}"
if [ -z "$PANEL_URL" ]; then
  IP="$(curl -4 -fsS --max-time 5 https://ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"
  [ -n "$IP" ] || fail "Public IP detect nahi hua. Dobara install chalakar PANEL_URL set karein."
  PANEL_URL="http://${IP}:${PANEL_PORT}"
fi
# Remove a trailing slash so APP_URL is stored consistently.
PANEL_URL="${PANEL_URL%/}"
info "Panel URL set: $PANEL_URL"
echo
info "Panel URL: $PANEL_URL   (badalna ho to:  PANEL_URL=https://panel.domain.com sudo -E bash install.sh)"

DB_NAME="panel"
DB_USER="pterodactyl"
DB_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 24)"

export DEBIAN_FRONTEND=noninteractive

# ---------------------------------------------------------------------
#  2. System packages
# ---------------------------------------------------------------------
info "System packages install ho rahe hain..."
apt-get update -y
apt-get install -y software-properties-common curl ca-certificates gnupg lsb-release apt-transport-https \
  unzip git tar zip nginx redis-server mariadb-server openssl cron python3

if [ "$ID" = "ubuntu" ]; then
  LC_ALL=C.UTF-8 add-apt-repository -y ppa:ondrej/php
else
  curl -fsSL https://packages.sury.org/php/apt.gpg -o /etc/apt/trusted.gpg.d/php.gpg
  echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" > /etc/apt/sources.list.d/php.list
fi
apt-get update -y
apt-get install -y php8.3 php8.3-{cli,fpm,common,gd,mysql,mbstring,bcmath,xml,curl,zip,intl,redis}

# Always use the same PHP version as the installed FPM service. In environments
# such as Codespaces, /usr/local/php may appear earlier in PATH and lack modules.
PHP_BIN="/usr/bin/php8.3"
[ -x "$PHP_BIN" ] || fail "PHP 8.3 CLI missing at $PHP_BIN; package installation failed."
MISSING_EXTS=()
for ext in pdo_mysql zip sodium bcmath; do
  if ! "$PHP_BIN" -m 2>/dev/null | tr '[:upper:]' '[:lower:]' | grep -qx "$ext"; then
    MISSING_EXTS+=("$ext")
  fi
done
if [ "${#MISSING_EXTS[@]}" -gt 0 ]; then
  echo "PHP 8.3 missing extensions: ${MISSING_EXTS[*]}" >&2
  echo "Installed PHP 8.3 modules:" >&2
  "$PHP_BIN" -m >&2 || true
  fail "Required PHP extensions are missing. Check php8.3-mysql, php8.3-zip, php8.3-common and php8.3-bcmath packages."
fi
ok "PHP 8.3 required extensions verified (pdo_mysql, zip, sodium, bcmath)."

# Composer
if ! command -v composer >/dev/null; then
  curl -fsSL https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
fi

# Node 22 + Yarn  (frontend build ke liye)
if ! command -v node >/dev/null || [ "$(node -v | sed 's/v\([0-9]*\).*/\1/')" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
command -v yarn >/dev/null || npm install -g yarn

# Start services robustly on normal VPSs and minimal containers (e.g. Codespaces).
service_start() {
  local svc="$1"
  if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null | tr -d ' ')" = "systemd" ]; then
    systemctl enable "$svc" >/dev/null 2>&1 || true
    systemctl restart "$svc" >/dev/null 2>&1 || systemctl start "$svc" >/dev/null 2>&1 || true
  elif command -v service >/dev/null 2>&1; then
    service "$svc" restart >/dev/null 2>&1 || service "$svc" start >/dev/null 2>&1 || true
  fi
}

service_start redis-server
service_start php8.3-fpm
service_start nginx

# MariaDB startup: service manager first, then direct daemon fallback if needed.
start_mariadb_direct() {
  mkdir -p /run/mysqld /var/log/mysql
  chown mysql:mysql /run/mysqld /var/log/mysql 2>/dev/null || true
  if command -v mariadb-install-db >/dev/null 2>&1 && [ ! -d /var/lib/mysql/mysql ]; then
    mariadb-install-db --user=mysql --datadir=/var/lib/mysql >/var/log/t-panel-db-init.log 2>&1 || true
  elif command -v mysql_install_db >/dev/null 2>&1 && [ ! -d /var/lib/mysql/mysql ]; then
    mysql_install_db --user=mysql --datadir=/var/lib/mysql >/var/log/t-panel-db-init.log 2>&1 || true
  fi
  if command -v mariadbd-safe >/dev/null 2>&1; then
    nohup mariadbd-safe --user=mysql --datadir=/var/lib/mysql --socket=/run/mysqld/mysqld.sock --pid-file=/run/mysqld/mysqld.pid >/var/log/t-panel-mariadb-start.log 2>&1 </dev/null &
  elif command -v mysqld_safe >/dev/null 2>&1; then
    nohup mysqld_safe --user=mysql --datadir=/var/lib/mysql --socket=/run/mysqld/mysqld.sock --pid-file=/run/mysqld/mysqld.pid >/var/log/t-panel-mariadb-start.log 2>&1 </dev/null &
  elif command -v mariadbd >/dev/null 2>&1; then
    nohup mariadbd --user=mysql --datadir=/var/lib/mysql --socket=/run/mysqld/mysqld.sock --pid-file=/run/mysqld/mysqld.pid >/var/log/t-panel-mariadb-start.log 2>&1 </dev/null &
  else
    return 1
  fi
}

wait_for_database() {
  local i
  for i in $(seq 1 45); do
    if mysqladmin --protocol=socket --socket=/run/mysqld/mysqld.sock ping --silent >/dev/null 2>&1 || mysqladmin ping --silent >/dev/null 2>&1; then
      return 0
    fi
    if [ "$i" -eq 1 ]; then
      service_start mariadb
      service_start mysql
      sleep 2
      if ! mysqladmin ping --silent >/dev/null 2>&1; then start_mariadb_direct || true; fi
    fi
    sleep 2
  done
  echo
  echo -e "${RED}[x]${NC} MariaDB start nahi hua. Neeche diagnostics dekho; database create nahi kiya gaya."
  if command -v systemctl >/dev/null 2>&1; then systemctl status mariadb --no-pager -l 2>&1 | tail -n 35 || true; fi
  if command -v service >/dev/null 2>&1; then service mariadb status 2>&1 || true; fi
  [ ! -f /var/log/t-panel-mariadb-start.log ] || tail -n 50 /var/log/t-panel-mariadb-start.log || true
  [ ! -f /var/log/t-panel-db-init.log ] || tail -n 30 /var/log/t-panel-db-init.log || true
  echo "Extra diagnostics: journalctl -u mariadb -n 80 --no-pager"
  exit 1
}
wait_for_database

# ---------------------------------------------------------------------
#  3. Copy panel files
# ---------------------------------------------------------------------
info "Panel files $INSTALL_DIR me copy ho rahe hain..."
mkdir -p "$INSTALL_DIR"
if [ "$SRC_DIR" != "$INSTALL_DIR" ]; then
  cp -a "$SRC_DIR"/. "$INSTALL_DIR"/
fi
cd "$INSTALL_DIR"
chmod -R 755 storage bootstrap/cache

# ---------------------------------------------------------------------
#  4. Database
# ---------------------------------------------------------------------
info "Database ban raha hai..."
wait_for_database
mysql -u root <<SQL
CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
ALTER USER '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
CREATE DATABASE IF NOT EXISTS ${DB_NAME};
GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'127.0.0.1' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL

# ---------------------------------------------------------------------
#  5. .env
# ---------------------------------------------------------------------
[ -f .env ] || cp .env.example .env
setenv() {  # setenv KEY VALUE; safely update dotenv without sed replacement bugs
  local k="$1" v="$2"
  python3 - "$k" "$v" <<'PYENV'
import os, re, sys, tempfile
key, value = sys.argv[1], sys.argv[2]
path = '.env'
# Quote values containing whitespace or dotenv-special characters.
if any(ch.isspace() for ch in value) or any(ch in value for ch in ('#', chr(34), chr(92))):
    encoded = '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'
else:
    encoded = value
with open(path, 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()
pattern = re.compile(r'^' + re.escape(key) + r'=')
replacement = f'{key}={encoded}'
found = False
for i, line in enumerate(lines):
    if pattern.match(line):
        if not found:
            lines[i] = replacement
            found = True
        else:
            lines[i] = ''
if not found:
    lines.append(replacement)
# Atomic write to avoid leaving a partially written .env.
fd, tmp = tempfile.mkstemp(prefix='.env.', dir='.')
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    os.chmod(tmp, 0o640)
    os.replace(tmp, path)
finally:
    if os.path.exists(tmp):
        os.unlink(tmp)
PYENV
}
setenv APP_URL "$PANEL_URL"
setenv APP_NAME "$PANEL_NAME"
setenv MAIL_FROM_NAME "$PANEL_NAME"
setenv APP_ENVIRONMENT_ONLY false
setenv DB_HOST 127.0.0.1
setenv DB_DATABASE "$DB_NAME"
setenv DB_USERNAME "$DB_USER"
setenv DB_PASSWORD "$DB_PASS"
setenv HASHIDS_SALT "$(tr -dc 'a-z0-9' </dev/urandom | head -c 20)"
setenv APP_SERVICE_AUTHOR "$ADMIN_EMAIL"
setenv MAIL_FROM_ADDRESS "$ADMIN_EMAIL"
# Fail early if the app name or URL was not written in a valid expected form.
grep -Eq '^APP_NAME="T Panel"$' .env || fail "APP_NAME .env mein sahi quote nahi hua."
grep -Eq '^APP_URL=.+' .env || fail "APP_URL .env mein missing hai."

# ---------------------------------------------------------------------
#  6. Composer + migrations
# ---------------------------------------------------------------------
info "PHP dependencies install ho rahi hain (composer)..."
export COMPOSER_ALLOW_SUPERUSER=1
# Skip Composer hooks until APP_KEY exists; Laravel package discovery may boot
# the application and fail with "No application encryption key" otherwise.
"$PHP_BIN" "$(command -v composer)" install --no-dev --optimize-autoloader --no-interaction --no-scripts || fail "Composer install fail hua. Upar diya gaya PHP/dependency error fix karna hoga."

# Generate the key before running any Laravel Composer hooks.
if ! grep -Eq '^APP_KEY=base64:.+' .env; then
  "$PHP_BIN" artisan key:generate --force || fail "APP_KEY generate nahi hui. PHP/OpenSSL aur .env permissions check karo."
fi
"$PHP_BIN" "$(command -v composer)" run-script post-autoload-dump --no-interaction || fail "Composer post-autoload hooks fail hue."
"$PHP_BIN" "$(command -v composer)" run-script post-install-cmd --no-interaction || warn "Composer post-install hook fail hua; install baad mein verify karo."
info "Database migrate + seed ho raha hai..."
"$PHP_BIN" artisan migrate --seed --force

# ---------------------------------------------------------------------
#  7. Frontend build
# ---------------------------------------------------------------------
info "Frontend build ho raha hai (yarn) - thoda time lagega..."
export NODE_OPTIONS=--openssl-legacy-provider
if ! yarn install --frozen-lockfile; then
  warn "Frozen Yarn install failed; retrying without frozen lockfile..."
  yarn install || fail "Yarn dependencies install nahi hui. Node/npm/yarn versions aur network check karo."
fi
yarn build:production || fail "Frontend build fail hua. Node.js/Yarn build log check karo."

# ---------------------------------------------------------------------
#  8. Admin user
# ---------------------------------------------------------------------
info "Admin user ban raha hai (full administrator privileges)..."
"$PHP_BIN" artisan p:user:make \
  --email="$ADMIN_EMAIL" \
  --username="$ADMIN_USERNAME" \
  --name-first="$ADMIN_FIRST" \
  --name-last="$ADMIN_LAST" \
  --password="$ADMIN_PASS" \
  --admin=1
ok "Account $ADMIN_USERNAME ko administrator privileges diye gaye hain."

# ---------------------------------------------------------------------
#  9. Permissions, cron, queue worker
# ---------------------------------------------------------------------
chown -R www-data:www-data "$INSTALL_DIR"

( crontab -l 2>/dev/null | grep -v "artisan schedule:run" ; \
  echo "* * * * * /usr/bin/php8.3 $INSTALL_DIR/artisan schedule:run >> /dev/null 2>&1" ) | crontab -

cat > /etc/systemd/system/pteroq.service <<UNIT
[Unit]
Description=T Panel Queue Worker
After=redis-server.service

[Service]
User=www-data
Group=www-data
Restart=always
ExecStart=/usr/bin/php8.3 $INSTALL_DIR/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
UNIT
if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null | tr -d ' ')" = "systemd" ]; then
  systemctl daemon-reload
  systemctl enable --now pteroq.service
else
  # Minimal containers do not run systemd; keep the queue worker in background.
  su -s /bin/sh www-data -c "nohup /usr/bin/php8.3 $INSTALL_DIR/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3 >> /var/log/pteroq.log 2>&1 </dev/null &" || warn "Queue worker auto-start nahi hua; normal VPS par systemd recommended hai."
fi

# ---------------------------------------------------------------------
#  10. Nginx
# ---------------------------------------------------------------------
rm -f /etc/nginx/sites-enabled/default
cat > /etc/nginx/sites-available/pterodactyl.conf <<NGINX
server {
    listen ${PANEL_PORT} default_server;
    server_name _;

    root ${INSTALL_DIR}/public;
    index index.php;

    access_log off;
    error_log  /var/log/nginx/pterodactyl.app-error.log error;

    client_max_body_size 100m;
    client_body_timeout 120s;
    sendfile off;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php\$ {
        fastcgi_split_path_info ^(.+\.php)(/.+)\$;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param PHP_VALUE "upload_max_filesize = 100M \n post_max_size=100M";
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param HTTP_PROXY "";
        fastcgi_intercept_errors off;
        fastcgi_buffer_size 16k;
        fastcgi_buffers 4 16k;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_read_timeout 300;
    }

    location ~ /\.ht { deny all; }
}
NGINX
ln -sf /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf
nginx -t
if command -v systemctl >/dev/null 2>&1 && [ "$(ps -p 1 -o comm= 2>/dev/null | tr -d ' ')" = "systemd" ]; then
  systemctl restart nginx
else
  nginx -s reload >/dev/null 2>&1 || nginx
fi
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PANEL_PORT}/tcp" || warn "UFW rule add nahi hui; manually TCP ${PANEL_PORT} allow karein."
fi

# ---------------------------------------------------------------------
#  Done
# ---------------------------------------------------------------------
echo
echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}   T Panel install ho gaya!${NC}"
echo -e "${GREEN}============================================${NC}"
echo " Panel    : T Panel"
echo " URL      : $PANEL_URL"
echo " Port     : $PANEL_PORT (TCP; firewall/provider firewall me allow karein)"
echo " Username : $ADMIN_USERNAME (ADMINISTRATOR)"
echo " Email    : $ADMIN_EMAIL"
echo " DB pass  : $DB_PASS   ($INSTALL_DIR/.env me bhi hai)"
echo
echo " Node (Wings) add karne ke liye:  bash node.sh"
