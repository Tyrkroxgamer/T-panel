#!/bin/bash
# =====================================================================
#  T Panel (Pterodactyl) - Automatic Installer
#  Usage:  sudo bash install.sh
#  Supports: Ubuntu 20.04/22.04/24.04, Debian 11/12
# =====================================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info() { echo -e "${CYAN}[*]${NC} $1"; }
ok()   { echo -e "${GREEN}[+]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
fail() { echo -e "${RED}[x]${NC} $1"; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Root se chalao:  sudo bash install.sh"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/var/www/pterodactyl"
PANEL_PORT="${PANEL_PORT:-8088}"

. /etc/os-release
case "$ID" in
  ubuntu|debian) ;;
  *) fail "Sirf Ubuntu / Debian supported hai (mila: $ID)" ;;
esac

# ---------------------------------------------------------------------
#  1. Setup: fixed panel branding; ask only for admin account and URL
# ---------------------------------------------------------------------
PANEL_NAME="T Panel"
echo
echo -e "${CYAN}========== T Panel Setup ==========${NC}"
while [ -z "$ADMIN_USERNAME" ]; do read -rp "Username   : " ADMIN_USERNAME; done
while ! [[ "$ADMIN_EMAIL" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]]; do read -rp "Email      : " ADMIN_EMAIL; done
while [ -z "$ADMIN_FIRST" ]; do read -rp "First name : " ADMIN_FIRST; done
while [ -z "$ADMIN_LAST" ];  do read -rp "Last name  : " ADMIN_LAST; done
while true; do
  read -rsp "Password   (min 8 chars): " ADMIN_PASS; echo
  [ "${#ADMIN_PASS}" -ge 8 ] || { warn "Password kam se kam 8 characters ka rakho."; continue; }
  read -rsp "Password again          : " ADMIN_PASS2; echo
  [ "$ADMIN_PASS" = "$ADMIN_PASS2" ] && break
  warn "Password match nahi hua, dobara try karo."
done

# Panel URL: user can enter a domain/IP URL; blank auto-detects the public IP.
echo
read -rp "Panel URL (e.g. http://1.2.3.4:${PANEL_PORT} or https://panel.example.com) [blank = auto-detect]: " INPUT_PANEL_URL
PANEL_URL="${INPUT_PANEL_URL:-${PANEL_URL:-}}"
if [ -z "$PANEL_URL" ]; then
  IP="$(curl -4 -fsS --max-time 5 https://ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}')"
  [ -n "$IP" ] || fail "Public IP detect nahi hua. Dobara install chalakar PANEL_URL set karein."
  PANEL_URL="http://${IP}:${PANEL_PORT}"
fi
# Remove a trailing slash so APP_URL is stored consistently.
PANEL_URL="${PANEL_URL%/}"
info "Panel URL set: $PANEL_URL"
echo
info "Panel URL: $PANEL_URL   (badalna ho to:  PANEL_URL=https://panel.domain.com sudo -E bash install.sh)"

DB_NAME="panel"
DB_USER="pterodactyl"
DB_PASS="$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 24)"

export DEBIAN_FRONTEND=noninteractive

# ---------------------------------------------------------------------
#  2. System packages
# ---------------------------------------------------------------------
info "System packages install ho rahe hain..."
apt-get update -y
apt-get install -y software-properties-common curl ca-certificates gnupg lsb-release apt-transport-https \
  unzip git tar zip nginx redis-server mariadb-server openssl cron

if [ "$ID" = "ubuntu" ]; then
  LC_ALL=C.UTF-8 add-apt-repository -y ppa:ondrej/php
else
  curl -fsSL https://packages.sury.org/php/apt.gpg -o /etc/apt/trusted.gpg.d/php.gpg
  echo "deb https://packages.sury.org/php/ $(lsb_release -sc) main" > /etc/apt/sources.list.d/php.list
fi
apt-get update -y
apt-get install -y php8.3 php8.3-{cli,fpm,common,gd,mysql,mbstring,bcmath,xml,curl,zip,intl,redis,posix}

# Composer
if ! command -v composer >/dev/null; then
  curl -fsSL https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
fi

# Node 22 + Yarn  (frontend build ke liye)
if ! command -v node >/dev/null || [ "$(node -v | sed 's/v\([0-9]*\).*/\1/')" -lt 22 ]; then
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
command -v yarn >/dev/null || npm install -g yarn

systemctl enable --now mariadb redis-server php8.3-fpm nginx

# ---------------------------------------------------------------------
#  3. Copy panel files
# ---------------------------------------------------------------------
info "Panel files $INSTALL_DIR me copy ho rahe hain..."
mkdir -p "$INSTALL_DIR"
if [ "$SRC_DIR" != "$INSTALL_DIR" ]; then
  cp -a "$SRC_DIR"/. "$INSTALL_DIR"/
fi
cd "$INSTALL_DIR"
chmod -R 755 storage bootstrap/cache

# ---------------------------------------------------------------------
#  4. Database
# ---------------------------------------------------------------------
info "Database ban raha hai..."
mysql -u root <<SQL
CREATE USER IF NOT EXISTS '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
ALTER USER '${DB_USER}'@'127.0.0.1' IDENTIFIED BY '${DB_PASS}';
CREATE DATABASE IF NOT EXISTS ${DB_NAME};
GRANT ALL PRIVILEGES ON ${DB_NAME}.* TO '${DB_USER}'@'127.0.0.1' WITH GRANT OPTION;
FLUSH PRIVILEGES;
SQL

# ---------------------------------------------------------------------
#  5. .env
# ---------------------------------------------------------------------
[ -f .env ] || cp .env.example .env
setenv() {  # setenv KEY VALUE
  local k="$1" v="$2"
  if grep -q "^${k}=" .env; then
    sed -i "s|^${k}=.*|${k}=${v//|/\\|}|" .env
  else
    echo "${k}=${v}" >> .env
  fi
}
setenv APP_URL "$PANEL_URL"
setenv APP_NAME "$PANEL_NAME"
setenv MAIL_FROM_NAME "$PANEL_NAME"
setenv APP_ENVIRONMENT_ONLY false
setenv DB_HOST 127.0.0.1
setenv DB_DATABASE "$DB_NAME"
setenv DB_USERNAME "$DB_USER"
setenv DB_PASSWORD "$DB_PASS"
setenv HASHIDS_SALT "$(tr -dc 'a-z0-9' </dev/urandom | head -c 20)"
setenv APP_SERVICE_AUTHOR "$ADMIN_EMAIL"
setenv MAIL_FROM_ADDRESS "$ADMIN_EMAIL"

# ---------------------------------------------------------------------
#  6. Composer + migrations
# ---------------------------------------------------------------------
info "PHP dependencies install ho rahi hain (composer)..."
export COMPOSER_ALLOW_SUPERUSER=1
composer install --no-dev --optimize-autoloader --no-interaction

php artisan key:generate --force
info "Database migrate + seed ho raha hai..."
php artisan migrate --seed --force

# ---------------------------------------------------------------------
#  7. Frontend build
# ---------------------------------------------------------------------
info "Frontend build ho raha hai (yarn) - thoda time lagega..."
export NODE_OPTIONS=--openssl-legacy-provider
yarn install --frozen-lockfile || yarn install
yarn build:production

# ---------------------------------------------------------------------
#  8. Admin user
# ---------------------------------------------------------------------
info "Admin user ban raha hai (full administrator privileges)..."
php artisan p:user:make \
  --email="$ADMIN_EMAIL" \
  --username="$ADMIN_USERNAME" \
  --name-first="$ADMIN_FIRST" \
  --name-last="$ADMIN_LAST" \
  --password="$ADMIN_PASS" \
  --admin=1
ok "Account $ADMIN_USERNAME ko administrator privileges diye gaye hain."

# ---------------------------------------------------------------------
#  9. Permissions, cron, queue worker
# ---------------------------------------------------------------------
chown -R www-data:www-data "$INSTALL_DIR"

( crontab -l 2>/dev/null | grep -v "artisan schedule:run" ; \
  echo "* * * * * php $INSTALL_DIR/artisan schedule:run >> /dev/null 2>&1" ) | crontab -

cat > /etc/systemd/system/pteroq.service <<UNIT
[Unit]
Description=T Panel Queue Worker
After=redis-server.service

[Service]
User=www-data
Group=www-data
Restart=always
ExecStart=/usr/bin/php $INSTALL_DIR/artisan queue:work --queue=high,standard,low --sleep=3 --tries=3
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now pteroq.service

# ---------------------------------------------------------------------
#  10. Nginx
# ---------------------------------------------------------------------
rm -f /etc/nginx/sites-enabled/default
cat > /etc/nginx/sites-available/pterodactyl.conf <<NGINX
server {
    listen ${PANEL_PORT} default_server;
    server_name _;

    root ${INSTALL_DIR}/public;
    index index.php;

    access_log off;
    error_log  /var/log/nginx/pterodactyl.app-error.log error;

    client_max_body_size 100m;
    client_body_timeout 120s;
    sendfile off;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php\$ {
        fastcgi_split_path_info ^(.+\.php)(/.+)\$;
        fastcgi_pass unix:/run/php/php8.3-fpm.sock;
        fastcgi_index index.php;
        include fastcgi_params;
        fastcgi_param PHP_VALUE "upload_max_filesize = 100M \n post_max_size=100M";
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        fastcgi_param HTTP_PROXY "";
        fastcgi_intercept_errors off;
        fastcgi_buffer_size 16k;
        fastcgi_buffers 4 16k;
        fastcgi_connect_timeout 300;
        fastcgi_send_timeout 300;
        fastcgi_read_timeout 300;
    }

    location ~ /\.ht { deny all; }
}
NGINX
ln -sf /etc/nginx/sites-available/pterodactyl.conf /etc/nginx/sites-enabled/pterodactyl.conf
nginx -t
systemctl restart nginx
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PANEL_PORT}/tcp" || warn "UFW rule add nahi hui; manually TCP ${PANEL_PORT} allow karein."
fi

# ---------------------------------------------------------------------
#  Done
# ---------------------------------------------------------------------
echo
echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}   T Panel install ho gaya!${NC}"
echo -e "${GREEN}============================================${NC}"
echo " Panel    : T Panel"
echo " URL      : $PANEL_URL"
echo " Port     : $PANEL_PORT (TCP; firewall/provider firewall me allow karein)"
echo " Username : $ADMIN_USERNAME (ADMINISTRATOR)"
echo " Email    : $ADMIN_EMAIL"
echo " DB pass  : $DB_PASS   ($INSTALL_DIR/.env me bhi hai)"
echo
echo " Node (Wings) add karne ke liye:  bash node.sh"
