#!/bin/bash
# =====================================================================
#  T Panel - Node (Wings) setup
#  Usage:  sudo bash node.sh
#  Panel me:  Admin -> Nodes -> (apna node) -> Configuration
#  wahan se Node ID aur Token (Generate Token) milta hai.
# =====================================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
info() { echo -e "${CYAN}[*]${NC} $1"; }
ok()   { echo -e "${GREEN}[+]${NC} $1"; }
fail() { echo -e "${RED}[x]${NC} $1"; exit 1; }

[ "$(id -u)" -eq 0 ] || fail "Root se chalao:  sudo bash node.sh"

echo -e "${CYAN}========== T Panel Node (Wings) Setup ==========${NC}"

# Order: Token -> ID -> Panel URL
while [ -z "$NODE_TOKEN" ]; do read -rp "Node Token : " NODE_TOKEN; done
while ! [[ "$NODE_ID" =~ ^[0-9]+$ ]]; do read -rp "Node ID    : " NODE_ID; done

if [ -z "$PANEL_URL" ]; then
  if [ -f /var/www/pterodactyl/.env ]; then
    PANEL_URL="$(grep '^APP_URL=' /var/www/pterodactyl/.env | cut -d= -f2-)"
    info "Panel URL (.env se): $PANEL_URL"
  else
    while [ -z "$PANEL_URL" ]; do read -rp "Panel URL  (e.g. https://panel.domain.com): " PANEL_URL; done
  fi
fi

# Docker
if ! command -v docker >/dev/null; then
  info "Docker install ho raha hai..."
  curl -fsSL https://get.docker.com/ | CHANNEL=stable bash
fi
systemctl enable --now docker

# Wings
info "Wings download ho raha hai..."
mkdir -p /etc/pterodactyl
case "$(uname -m)" in
  x86_64)  ARCH=amd64 ;;
  aarch64) ARCH=arm64 ;;
  *) fail "Unsupported architecture: $(uname -m)" ;;
esac
curl -fsSL -o /usr/local/bin/wings \
  "https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_${ARCH}"
chmod u+x /usr/local/bin/wings

# Config
info "Wings configure ho raha hai..."
/usr/local/bin/wings configure --panel-url "$PANEL_URL" --token "$NODE_TOKEN" --node "$NODE_ID" --allow-insecure

# Service
cat > /etc/systemd/system/wings.service <<UNIT
[Unit]
Description=T Panel Wings Daemon
After=docker.service
Requires=docker.service
PartOf=docker.service

[Service]
User=root
WorkingDirectory=/etc/pterodactyl
LimitNOFILE=4096
PIDFile=/var/run/wings/daemon.pid
ExecStart=/usr/local/bin/wings
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now wings

echo
ok "Node setup ho gaya! Status check:  systemctl status wings"
