#!/usr/bin/env bash
set -Eeuo pipefail

# Repair Laravel dotenv values that contain spaces (notably APP_NAME="T Panel").
# Run from the project root, or pass a project directory as the first argument.
TARGET="${1:-$(pwd)}"
if [[ ! -f "$TARGET/artisan" ]]; then
  echo "ERROR: $TARGET mein artisan file nahi mili. Usage: bash repair-env.sh /path/to/T-PANEL" >&2
  exit 1
fi
cd "$TARGET"
if [[ ! -f .env ]]; then
  if [[ -f .env.example ]]; then
    cp .env.example .env
    echo "Created .env from .env.example"
  else
    echo "ERROR: .env aur .env.example dono nahi mile." >&2
    exit 1
  fi
fi

python3 <<'PY'
import os, re, tempfile
path = '.env'
with open(path, 'r', encoding='utf-8') as f:
    lines = f.read().splitlines()
updates = {'APP_NAME': '"T Panel"', 'MAIL_FROM_NAME': '"T Panel"'}
for key, value in updates.items():
    pattern = re.compile(r'^' + re.escape(key) + r'=')
    found = False
    for i, line in enumerate(lines):
        if pattern.match(line):
            if not found:
                lines[i] = f'{key}={value}'
                found = True
            else:
                lines[i] = ''
    if not found:
        lines.append(f'{key}={value}')
fd, tmp = tempfile.mkstemp(prefix='.env.repair.', dir='.')
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    os.chmod(tmp, 0o640)
    os.replace(tmp, path)
finally:
    if os.path.exists(tmp):
        os.unlink(tmp)
PY

echo "Updated .env values:"
grep -E '^(APP_NAME|MAIL_FROM_NAME)=' .env

# Generate APP_KEY with openssl (artisan cannot boot while APP_KEY is empty).
if ! grep -Eq '^APP_KEY=base64:.{40,}' .env; then
  NEWKEY="base64:$(openssl rand -base64 32)"
  if grep -q '^APP_KEY=' .env; then
    python3 - "$NEWKEY" <<'PYK'
import sys,re
v=sys.argv[1]
t=open('.env').read()
t=re.sub(r'^APP_KEY=.*$', 'APP_KEY='+v, t, count=1, flags=re.M)
open('.env','w').write(t)
PYK
  else
    echo "APP_KEY=$NEWKEY" >> .env
  fi
  echo "APP_KEY generated."
fi

PHP_BIN=""
for candidate in /usr/bin/php8.3 /usr/bin/php8.2 /usr/bin/php /usr/local/php/8.4.15/bin/php; do
  if [[ -x "$candidate" ]]; then PHP_BIN="$candidate"; break; fi
done
if [[ -z "$PHP_BIN" ]]; then
  echo "Env fix done, but PHP CLI was not found; run Composer/Artisan after installing PHP." >&2
  exit 2
fi
if [[ ! -f vendor/autoload.php ]]; then
  echo "Env fix done. vendor/autoload.php missing; dependencies are not installed yet."
  echo "PHP selected: $PHP_BIN"
  exit 0
fi
"$PHP_BIN" artisan config:clear
"$PHP_BIN" artisan package:discover --ansi
