#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with sudo: sudo ./uninstall.sh"; exit 1; fi
echo "=== T PANEL Uninstaller ==="
echo "This removes the T PANEL web application and its service manager."
echo "Minecraft data and Docker are kept by default."
read -r -p "Remove T PANEL application and service? [y/N]: " CONFIRM
case "${CONFIRM,,}" in y|yes) ;; *) echo "Cancelled."; exit 0 ;; esac
if command -v systemctl >/dev/null 2>&1 && [[ "$(ps -p 1 -o comm= 2>/dev/null | tr -d ' ')" == "systemd" ]]; then
  systemctl disable --now t-panel 2>/dev/null || true
  rm -f /etc/systemd/system/t-panel.service
  systemctl daemon-reload || true
fi
if command -v t-panel-service >/dev/null 2>&1; then t-panel-service stop || true; fi
rm -f /usr/local/bin/t-panel-service
rm -rf /opt/t-panel
echo "T PANEL application removed."
echo "Kept: /var/lib/t-panel (server files, backups, accounts and config)."
read -r -p "Also delete T PANEL data and its Minecraft container? Type DELETE to confirm: " DELETE_DATA
if [[ "$DELETE_DATA" == "DELETE" ]]; then
  docker rm -f t-panel-minecraft 2>/dev/null || true
  rm -rf /var/lib/t-panel
  echo "T PANEL data and its Minecraft container removed."
else echo "Data retained."; fi
echo "Docker was not uninstalled because other apps may use it."
