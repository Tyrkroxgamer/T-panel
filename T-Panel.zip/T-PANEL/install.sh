#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with sudo: sudo ./install.sh"; exit 1; fi
APP_DIR="/opt/t-panel"
DATA_DIR="/var/lib/t-panel"
SERVICE="t-panel"
SYSTEMD=0
if [[ "$(ps -p 1 -o comm= 2>/dev/null | tr -d ' ')" == "systemd" ]] && command -v systemctl >/dev/null 2>&1; then SYSTEMD=1; fi

echo "=== T PANEL Installer ==="
read -r -p "Panel web port [8088]: " PORT
PORT="${PORT:-8088}"
if ! [[ "$PORT" =~ ^[0-9]+$ ]] || (( PORT < 1024 || PORT > 65535 )); then echo "Invalid port."; exit 1; fi
if command -v ss >/dev/null 2>&1 && ss -ltnH | awk '{print $4}' | grep -Eq "(^|:)${PORT}$"; then
  echo "ERROR: TCP port $PORT is already in use. Choose another port or stop the service using it."
  exit 1
fi
read -r -p "Admin username [admin]: " ADMIN
ADMIN="${ADMIN:-admin}"
read -r -s -p "Admin password (min 10 characters): " PASSWORD; echo
if (( ${#PASSWORD} < 10 )); then echo "Password must be at least 10 characters."; exit 1; fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip curl ca-certificates openssh-client iproute2 init-system-helpers
# Do not let an optional Docker package conflict prevent the web panel from installing.
if ! command -v docker >/dev/null 2>&1; then
  apt-get install -y docker.io || echo "WARNING: Docker package installation failed (often due to an existing Docker/containerd setup). Continuing with panel installation."
fi
id -u tpanel >/dev/null 2>&1 || useradd --system --home-dir "$DATA_DIR" --shell /usr/sbin/nologin tpanel
getent group docker >/dev/null 2>&1 || groupadd docker
usermod -aG docker tpanel
mkdir -p "$APP_DIR" "$DATA_DIR/server" "$DATA_DIR/backups"
cp -r ./* "$APP_DIR/"
chmod +x "$APP_DIR/install.sh" "$APP_DIR/uninstall.sh"
python3 -m venv "$APP_DIR/venv"
"$APP_DIR/venv/bin/pip" install --upgrade pip
"$APP_DIR/venv/bin/pip" install -r "$APP_DIR/requirements.txt"
export T_PANEL_PORT="$PORT" T_PANEL_ADMIN="$ADMIN" T_PANEL_PASSWORD="$PASSWORD"
"$APP_DIR/venv/bin/python" - <<'PYCONFIG'
import os, json, secrets, hashlib, pathlib
p=pathlib.Path('/var/lib/t-panel/config.json')
p.parent.mkdir(parents=True, exist_ok=True)
salt=secrets.token_hex(16)
pw=hashlib.pbkdf2_hmac('sha256', os.environ['T_PANEL_PASSWORD'].encode(), salt.encode(), 240000).hex()
json.dump({'port':int(os.environ['T_PANEL_PORT']),'username':os.environ['T_PANEL_ADMIN'],'salt':salt,'password_hash':pw,'secret':secrets.token_hex(32)},open(p,'w'))
os.chmod(p,0o600)
PYCONFIG
unset PASSWORD T_PANEL_PASSWORD
chown -R root:root "$APP_DIR"
chown -R tpanel:tpanel "$DATA_DIR"

# Install a service wrapper that works both with systemd and in containers without systemd.
install -m 0755 "$APP_DIR/t-panel-service.sh" /usr/local/bin/t-panel-service
if (( SYSTEMD )); then
  cat > /etc/systemd/system/${SERVICE}.service <<EOF
[Unit]
Description=T PANEL Minecraft Server Manager
After=network.target docker.service
Wants=docker.service

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=T_PANEL_CONFIG=$DATA_DIR/config.json
Environment=T_PANEL_DATA=$DATA_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/app.py
Restart=on-failure
RestartSec=3
User=tpanel
Group=tpanel
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full
ReadWritePaths=$DATA_DIR

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable --now docker || true
  systemctl enable --now "$SERVICE"
else
  echo "No systemd detected; using t-panel-service process manager."
  # In containers, the service command may work even when systemd does not.
  service docker start >/dev/null 2>&1 || true
  t-panel-service start
fi

# Docker may not be allowed inside a nested development container; don't prevent the web UI from starting.
if docker info >/dev/null 2>&1; then
  echo "Docker Engine is available."
else
  echo "WARNING: Docker Engine is installed but its daemon is not reachable in this environment."
  echo "The web panel can open, but Minecraft server controls need a working Docker daemon/socket."
  echo "On a container host, enable Docker access or run this panel on a Docker-capable VPS."
fi
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then ufw allow "$PORT/tcp" || true; fi
sleep 2
if (( SYSTEMD )); then
  if ! systemctl is-active --quiet "$SERVICE"; then echo "ERROR: Panel failed. Logs:"; journalctl -u "$SERVICE" -n 60 --no-pager || true; exit 1; fi
else
  if ! t-panel-service status >/dev/null 2>&1; then echo "ERROR: Panel failed. Recent log:"; tail -n 80 "$DATA_DIR/panel.log" 2>/dev/null || true; exit 1; fi
fi
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
[[ -n "$IP" ]] || IP="127.0.0.1"
echo
echo "T PANEL installed."
echo "Panel URL: http://${IP}:${PORT}"
echo "Local URL: http://127.0.0.1:${PORT}"
echo "Service control: t-panel-service {start|stop|restart|status|logs}"
if (( SYSTEMD )); then echo "Systemd logs: journalctl -u t-panel -f"; fi
echo "Panel log: $DATA_DIR/panel.log"
echo "Server files: $DATA_DIR/server"
echo "If it does not open externally, allow TCP $PORT in your provider firewall/security group."
