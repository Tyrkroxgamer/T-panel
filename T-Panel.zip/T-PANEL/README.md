# T PANEL — Minecraft Server Manager

Docker-backed Minecraft Java server management panel for Ubuntu Linux.

## Included features
- Login, public Register, and admin user management
- Docker start/stop/restart, live log view and RCON commands for supported backend servers
- Software selector: Vanilla, Paper, Purpur, Folia, Fabric, Forge, NeoForge, Quilt, Spigot, Bukkit, Velocity, Waterfall and BungeeCord (actual version/software availability depends on upstream image support)
- Dynamic upstream version list for supported software types
- Plugin search/install/remove via Modrinth for compatible plugin software
- Mod search/install/remove via Modrinth for Fabric/Forge/NeoForge/Quilt
- Player list and Kick/Ban/Unban/OP/DeOP via RCON for backend servers
- File manager: browse, edit small text files, upload, download, create folders and delete files/folders
- Manual ZIP backups and downloads; no automatic backup or scheduled auto-restart feature
- Admin server settings (RAM, public port, MOTD, max players)
- Remote node registry, SSH test, remote Docker container listing and start/stop/restart using SSH keys
- `install.sh` and `uninstall.sh`

## Install
```bash
chmod +x install.sh uninstall.sh
sudo ./install.sh
```
The installer asks for panel port and administrator credentials and installs required packages. It creates a systemd service on systemd hosts; inside containers without systemd, it uses `t-panel-service` and writes logs to `/var/lib/t-panel/panel.log`. Docker controls require a reachable Docker daemon/socket.

## Important limitations
- This is a lightweight panel, not a drop-in feature-equivalent Pterodactyl replacement. It currently manages one local Minecraft container; full multi-server allocation/subuser quotas and full remote node agent deployment are not implemented.
- Velocity/Waterfall/BungeeCord are proxy software; they need separately configured backend servers and do not use Minecraft backend RCON/player moderation in this panel.
- Fabric/Forge-family mod compatibility depends on the exact game/loader version. Confirm mod dependencies before installing.
- Version lists depend on upstream APIs and are not a promise that every historical Minecraft release works with every software type.
- Public Register creates standard user accounts. Admin Settings and Remote Nodes are admin-only. This lightweight app should be put behind HTTPS and restricted network access before internet exposure; it has not received a full production security audit.
- Test on a non-production VPS first and keep manual backups before changing server software or versions.
