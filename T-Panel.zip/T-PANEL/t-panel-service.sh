#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/t-panel"
DATA_DIR="/var/lib/t-panel"
PID_FILE="$DATA_DIR/panel.pid"
LOG_FILE="$DATA_DIR/panel.log"
ACTION="${1:-status}"
mkdir -p "$DATA_DIR"
case "$ACTION" in
  start)
    if command -v start-stop-daemon >/dev/null 2>&1 && start-stop-daemon --status --pidfile "$PID_FILE" >/dev/null 2>&1; then
      echo "T PANEL is already running."; exit 0
    fi
    rm -f "$PID_FILE"
    if [[ ! -x "$APP_DIR/venv/bin/python" || ! -f "$APP_DIR/app.py" ]]; then echo "T PANEL files missing under $APP_DIR. Run install.sh first."; exit 1; fi
    touch "$LOG_FILE"; chown tpanel:tpanel "$LOG_FILE" 2>/dev/null || true
    if command -v start-stop-daemon >/dev/null 2>&1 && id tpanel >/dev/null 2>&1; then
      start-stop-daemon --start --background --make-pidfile --pidfile "$PID_FILE" --chuid tpanel --chdir "$APP_DIR" --startas /usr/bin/env -- T_PANEL_CONFIG="$DATA_DIR/config.json" T_PANEL_DATA="$DATA_DIR" PYTHONUNBUFFERED=1 "$APP_DIR/venv/bin/python" "$APP_DIR/app.py" >>"$LOG_FILE" 2>&1
    else
      (cd "$APP_DIR" && env T_PANEL_CONFIG="$DATA_DIR/config.json" T_PANEL_DATA="$DATA_DIR" PYTHONUNBUFFERED=1 "$APP_DIR/venv/bin/python" "$APP_DIR/app.py") >>"$LOG_FILE" 2>&1 &
      echo $! > "$PID_FILE"
    fi
    sleep 2
    if command -v start-stop-daemon >/dev/null 2>&1; then
      if start-stop-daemon --status --pidfile "$PID_FILE" >/dev/null 2>&1; then echo "T PANEL started."; else echo "T PANEL failed to start. Check: t-panel-service logs"; rm -f "$PID_FILE"; exit 1; fi
    else
      if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then echo "T PANEL started."; else echo "T PANEL failed to start. Check: t-panel-service logs"; rm -f "$PID_FILE"; exit 1; fi
    fi
    ;;
  stop)
    if command -v start-stop-daemon >/dev/null 2>&1; then
      start-stop-daemon --stop --pidfile "$PID_FILE" --retry=TERM/10/KILL/5 >/dev/null 2>&1 || true
    elif [[ -f "$PID_FILE" ]]; then
      kill "$(cat "$PID_FILE")" 2>/dev/null || true
    fi
    rm -f "$PID_FILE"; echo "T PANEL stopped." ;;
  restart) "$0" stop; "$0" start ;;
  status)
    if command -v start-stop-daemon >/dev/null 2>&1 && start-stop-daemon --status --pidfile "$PID_FILE" >/dev/null 2>&1; then echo "T PANEL running."; exit 0; fi
    if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then echo "T PANEL running (PID $(cat "$PID_FILE"))."; exit 0; fi
    echo "T PANEL not running."; exit 1 ;;
  logs) touch "$LOG_FILE"; tail -n 100 -f "$LOG_FILE" ;;
  *) echo "Usage: t-panel-service {start|stop|restart|status|logs}"; exit 2 ;;
esac
